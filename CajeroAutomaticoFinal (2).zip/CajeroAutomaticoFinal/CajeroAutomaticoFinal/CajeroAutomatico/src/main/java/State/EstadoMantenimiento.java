package state;

import javax.swing.JOptionPane;

public class EstadoMantenimiento implements EstadoCajero {
    private final CajeroContexto contexto;

    public EstadoMantenimiento(CajeroContexto contexto) {
        this.contexto = contexto;
    }

    @Override
    public void ejecutar() {
        // Mostrar aviso de mantenimiento
        JOptionPane.showMessageDialog(null,
            "⚠️ El cajero está en mantenimiento. No se pueden realizar operaciones.",
            "Mantenimiento",
            JOptionPane.INFORMATION_MESSAGE);

    }
}
