package state;

import javax.swing.JFrame;
import Vista.MenuPrincipal;

public class EstadoMenuPrincipal implements EstadoCajero {
    private final CajeroContexto contexto;

    public EstadoMenuPrincipal(CajeroContexto contexto) {
        this.contexto = contexto;
    }

    @Override
    public void ejecutar() {
        MenuPrincipal menuPrincipalFrame = new MenuPrincipal();
        menuPrincipalFrame.setVisible(true);
    }
}
