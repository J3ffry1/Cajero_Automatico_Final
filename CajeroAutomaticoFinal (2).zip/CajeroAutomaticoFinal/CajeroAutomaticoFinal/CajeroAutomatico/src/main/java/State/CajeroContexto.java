package state;

import Modelo.ServicioUsuario;
import persistencia.ServicioTrans;

public class CajeroContexto {
    private EstadoCajero estadoActual;
    private ServicioUsuario servicioUsuario;
    private ServicioTrans servicioTrans;

    public CajeroContexto(ServicioUsuario servicioUsuario, ServicioTrans servicioTrans) {
        this.servicioUsuario = servicioUsuario;
        this.servicioTrans = servicioTrans;
    }

    public void setEstado(EstadoCajero estado) {
        this.estadoActual = estado;
    }

    public void ejecutar() {
        if (estadoActual != null) {
            estadoActual.ejecutar();
        } else {
            System.out.println("No hay estado asignado.");
        }
    }
}
