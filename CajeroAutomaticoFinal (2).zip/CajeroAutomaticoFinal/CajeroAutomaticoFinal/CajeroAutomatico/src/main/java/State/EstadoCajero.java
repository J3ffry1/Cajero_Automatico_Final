package state;

public interface EstadoCajero {
    void ejecutar();
}
