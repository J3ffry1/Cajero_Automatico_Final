package Modelo;



public class Usuario {
    private String usuario;
    private String contrasena;
    private double saldo;
    private String nombreCompleto;
    private String apellidos;
    private String fechaNacimiento;
    private String telefono;
    private String correo;
    private String pais;
   public Usuario() {
       Usuario usuario = new Usuario("usuario", "contraseña", saldo, "nombre", "fechaNacimiento", "telefono", "pais", "apellidos", "correo");
    }
    public Usuario(String usuario, String contrasena, double saldo, String nombreCompleto, String fechaNacimiento, String telefono, String pais, String apellidos,String correo) {
        this.usuario = usuario;
        this.contrasena = contrasena;
        this.saldo = saldo;
        this.nombreCompleto = nombreCompleto;
        this.fechaNacimiento = fechaNacimiento;
        this.telefono = telefono;
        this.pais= pais;
        this.apellidos=apellidos;
        this.correo = correo;
    }

    public String getUsuario() {
        return usuario;
    }

    public String getContrasena() {
        return contrasena;
    }

    public double getSaldo() {
        return saldo;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public String getFechaNacimiento() {
        return fechaNacimiento;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getCorreo() {
        return correo;
    }
    
    public String getPais(){
    return pais;
    }
    public String getApellidos(){
    return apellidos;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public void setContrasena(String contrasena) {
        this.contrasena = contrasena;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public void setFechaNacimiento(String fechaNacimiento) {
        this.fechaNacimiento = fechaNacimiento;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public void setApellidos(String apellidos){
       this.apellidos= apellidos;
    }
    public void setPais(String pais){
       this.pais = pais;
    }


}
