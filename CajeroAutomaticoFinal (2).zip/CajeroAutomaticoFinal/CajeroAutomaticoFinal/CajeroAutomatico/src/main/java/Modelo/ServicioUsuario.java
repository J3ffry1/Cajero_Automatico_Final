
package Modelo;

public interface ServicioUsuario {
    
    boolean autenticarUsuario(String usuario, String contrasena);
    void guardarUsuario(Usuario usuario);
    double obtenerSaldo(String usuario);
    void actualizarSaldo(String usuario, double monto);
    boolean verificarCuentaExistente(String numeroCuenta);
    String obtenerNombreCuenta(String numeroCuenta);
}
