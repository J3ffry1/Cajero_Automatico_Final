
package persistencia;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import Modelo.Usuario;
import Modelo.ServicioUsuario;
import java.util.ArrayList;
import java.util.List;
import org.bson.Document;


public class ConexionMongo  implements ServicioUsuario{
    private static final String URI = "mongodb://127.0.0.1:27017";
    private static final String DATABASE = "Usuarios_Registrados_db";

    MongoDatabase database;
    MongoCollection<Document> coleccion;

    public ConexionMongo() {
        MongoClient mongoClient = MongoClients.create(URI);
        database = mongoClient.getDatabase(DATABASE);
        coleccion = database.getCollection("Usuarios"); // 💥 Esta línea es CLAVE
    }
    @Override
    public boolean autenticarUsuario(String usuario, String contrasena) {
    Document filtro = new Document("usuario", usuario).append("contrasena", contrasena);
    Document resultado = coleccion.find(filtro).first();
    return resultado != null;
}

    @Override
    public void guardarUsuario(Usuario usuario) {
        Document doc = new Document("usuario", usuario.getUsuario())
                .append("contrasena", usuario.getContrasena())
                .append("saldo", usuario.getSaldo())
                .append("nombres", usuario.getNombreCompleto())
                .append("apellidos",usuario.getApellidos())
                .append("fechaNacimiento", usuario.getFechaNacimiento())
                .append("pais", usuario.getPais())
                .append("telefono", usuario.getTelefono())
                .append("correo", usuario.getCorreo());
        coleccion.insertOne(doc);
    }
    @Override
   public double obtenerSaldo(String usuario) {
    Document filtro = new Document("usuario", usuario);
    Document resultado = coleccion.find(filtro).first();
    return resultado != null ? resultado.getDouble("saldo") : 0.0;
}
    @Override
    public void actualizarSaldo(String usuario, double monto) {
    Document filtro = new Document("usuario", usuario);
    // Primero obtener el saldo actual
    Document usuarioDoc = coleccion.find(filtro).first();
    if (usuarioDoc != null) {
        double saldoActual = usuarioDoc.getDouble("saldo");
        double nuevoSaldo = saldoActual + monto; // Sumar o restar según el monto
        
        Document update = new Document("$set", new Document("saldo", nuevoSaldo)); // ✅ Corrección
        coleccion.updateOne(filtro, update);
    }
}
//transferencia internacional verifica

    @Override
    public boolean verificarCuentaExistente(String numeroCuenta) {
    try {
        Document query = new Document("usuario", numeroCuenta);
        long count = coleccion.countDocuments(query);
        return count > 0;
    } catch (Exception e) {
        System.err.println("Error al verificar cuenta: " + e.getMessage());
        return false;
    }
}

public String obtenerNombreCuenta(String numeroCuenta) {
    try {
        Document doc = coleccion.find(new Document("usuario", numeroCuenta)).first();
        if (doc != null) {
            String nombres = doc.getString("nombres");      // coincide con guardarUsuario
            String apellidos = doc.getString("apellidos");
            return nombres + " " + apellidos;
        } else {
            return "Cuenta no encontrada";
        }
    } catch (Exception e) {
        System.err.println("Error al obtener nombre: " + e.getMessage());
        return "Error al obtener información";
    }
}


}
