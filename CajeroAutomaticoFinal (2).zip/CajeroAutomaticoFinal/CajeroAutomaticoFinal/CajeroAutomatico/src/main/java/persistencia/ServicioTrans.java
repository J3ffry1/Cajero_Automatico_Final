/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package persistencia;

public interface ServicioTrans {
    /**
     * Registra una transacción en el sistema
     * @param usuario Nombre de usuario
     * @param tipo Tipo de transacción (DEPOSITO, RETIRO, etc.)
     * @param monto Monto de la transacción
     */
    void registrarTransaccion(String usuario, String tipo, double monto);
    /**
     * Obtiene el historial de transacciones de un usuario
     * @param usuario Nombre de usuario
     * @return Historial formateado como String
     */
    String obtenerHistorial(String usuario);
    /**
     * Verifica si una transacción excede el límite permitido
     * @param monto Monto a verificar
     * @return true si está dentro del límite
     */
    boolean validarLimiteTransaccion(double monto);
}
