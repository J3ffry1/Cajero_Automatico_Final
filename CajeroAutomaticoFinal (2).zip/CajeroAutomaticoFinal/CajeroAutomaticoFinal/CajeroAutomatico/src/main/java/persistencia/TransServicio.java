
package persistencia;

import persistencia.ServicioTrans;
import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.locks.ReentrantLock;

public class TransServicio implements ServicioTrans {
    private static final String CSV_FILE = "transacciones.csv";
    private static final DateTimeFormatter DATE_FORMAT = 
        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final ReentrantLock lock = new ReentrantLock();
    private static final double LIMITE_TRANSACCION = 5000.00; // Límite por operación

    @Override
    public void registrarTransaccion(String usuario, String tipo, double monto) {
        lock.lock();
        try {
            crearArchivoSiNoExiste();
            
            try (FileWriter writer = new FileWriter(CSV_FILE, true)) {
                String linea = String.format("%s,%s,%.2f,%s%n",
                    usuario, 
                    tipo, 
                    monto, 
                    LocalDateTime.now().format(DATE_FORMAT));
                writer.append(linea);
            }
        } catch (IOException e) {
            System.err.println("Error crítico al registrar transacción: " + e.getMessage());
        } finally {
            lock.unlock();
        }
    }

    @Override
    public String obtenerHistorial(String usuario) {
        lock.lock();
        try {
            File file = new File(CSV_FILE);
            if (!file.exists()) {
                return "No hay historial disponible";
            }

            StringBuilder historial = new StringBuilder();
            historial.append("=== Historial de Transacciones ===\n");
            historial.append(String.format("%-12s %-10s %-15s %-20s%n", 
                "Usuario", "Tipo", "Monto", "Fecha/Hora"));

            try (BufferedReader reader = new BufferedReader(new FileReader(CSV_FILE))) {
                String linea;
                boolean primeraLinea = true;
                
                while ((linea = reader.readLine()) != null) {
                    if (primeraLinea) {
                        primeraLinea = false;
                        continue; // Saltar cabecera
                    }
                    
                    String[] datos = linea.split(",");
                    if (datos.length >= 4 && datos[0].equals(usuario)) {
                        historial.append(String.format("%-12s %-10s $%-14.2f %-20s%n",
                            datos[0], datos[1], Double.parseDouble(datos[2]), datos[3]));
                    }
                }
            }
            
            return historial.length() > 0 ? historial.toString() : "No hay transacciones registradas";
        } catch (Exception e) {
            return "Error al leer historial: " + e.getMessage();
        } finally {
            lock.unlock();
        }
    }

    @Override
    public boolean validarLimiteTransaccion(double monto) {
        return monto <= LIMITE_TRANSACCION;
    }

    // ======= Métodos auxiliares ======= //
    private void crearArchivoSiNoExiste() throws IOException {
        File file = new File(CSV_FILE);
        if (!file.exists()) {
            try (FileWriter writer = new FileWriter(CSV_FILE)) {
                writer.append("Usuario,Tipo,Monto,FechaHora\n");
            }
        }
    }
}