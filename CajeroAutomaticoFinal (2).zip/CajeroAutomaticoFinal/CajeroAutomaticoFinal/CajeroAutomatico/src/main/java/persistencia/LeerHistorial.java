package persistencia;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.locks.ReentrantLock;

public class LeerHistorial {
    private final String archivoCSV;
    private static final DateTimeFormatter DATE_FORMAT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final ReentrantLock lock = new ReentrantLock();

    public LeerHistorial() {
        this.archivoCSV = "transacciones.csv";
    }

    public LeerHistorial(String archivoCSV) {
        this.archivoCSV = archivoCSV;
    }

    public String leerHistorial(String usuario) {
        lock.lock();
        try {
            File file = new File(archivoCSV);
            if (!file.exists()) {
                return "No hay historial de transacciones disponible";
            }

            StringBuilder historial = new StringBuilder();
            historial.append("=== Historial de Transacciones ===\n");
            historial.append(String.format("%-20s %-25s %-10s %s%n",
                    "Tipo", "Fecha y Hora", "Monto", "Saldo"));

            boolean tieneTransacciones = false;
            double saldoAcumulado = 0;

            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String linea;
                boolean primeraLinea = true;

                while ((linea = reader.readLine()) != null) {
                    if (primeraLinea) {
                        primeraLinea = false;
                        continue;
                    }

                    String[] datos = linea.split(",");
                    if (datos.length >= 4 && datos[0].equals(usuario)) {
                        tieneTransacciones = true;

                        String tipo = datos[1];
                        double monto = Double.parseDouble(datos[2]);
                        String fecha = datos[3];

                       if (tipo.equalsIgnoreCase("DEPOSITO")) {
    saldoAcumulado += monto;
} else if (tipo.equalsIgnoreCase("RETIRO")) {
    saldoAcumulado -= monto;
} else {
    // Tipo desconocido, ignoramos la transacción
    continue;
}

historial.append(String.format("%-20s %-25s $%-9.2f $%.2f%n",
        tipo, fecha, monto, saldoAcumulado));

                    }
                }
            }

            if (!tieneTransacciones) {
                return "No hay transacciones registradas";
            }

            return historial.toString();
        } catch (Exception e) {
            return "Error al leer el historial: " + e.getMessage();
        } finally {
            lock.unlock();
        }
    }
}
