package Vista;

import Modelo.ServicioUsuario;
import State.ServicioTransImpl;
import State.ServicioUsuarioImpl;

import persistencia.ServicioTrans;
import state.CajeroContexto;
import state.EstadoMenuPrincipal;
import state.EstadoMantenimiento;
import state.EstadoCajero;

public class CajeroAutomatico {
    public static void main(String[] args) {
        ServicioUsuario servicioUsuario = new ServicioUsuarioImpl();
        ServicioTrans servicioTrans = new ServicioTransImpl();

        CajeroContexto contexto = new CajeroContexto(servicioUsuario, servicioTrans);

        boolean modoMantenimiento = false; // True para Activar el modo mantenimiento.

        EstadoCajero estadoInicial;

        if (modoMantenimiento) {
            estadoInicial = new EstadoMantenimiento(contexto);
        } else {
            estadoInicial = new EstadoMenuPrincipal(contexto);
        }

        contexto.setEstado(estadoInicial);
        contexto.ejecutar();
    }
}
