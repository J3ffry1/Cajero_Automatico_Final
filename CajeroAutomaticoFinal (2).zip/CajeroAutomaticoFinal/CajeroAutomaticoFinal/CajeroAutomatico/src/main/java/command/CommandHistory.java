
package command;
import java.util.Stack;

public class CommandHistory {
    private final Stack<Command> history = new Stack<>();
    private final Stack<Command> redoStack = new Stack<>();

    public void push(Command command) {
        history.push(command);
        redoStack.clear(); // Limpiar redo al hacer nueva acción
    }
    public boolean canUndo() {
        return !history.isEmpty();
    }
    public boolean canRedo() {
        return !redoStack.isEmpty();
    }
    public void undo() {
        if (canUndo()) {
            Command command = history.pop();
            command.undo();
            redoStack.push(command);
        }
    }
    public void redo() {
        if (canRedo()) {
            Command command = redoStack.pop();
            command.execute();
            history.push(command);
        }
    }
}
