package command;

import Modelo.ServicioUsuario;
import persistencia.ServicioTrans;

public class TransferenciaCommand implements Command {
    private final ServicioUsuario servicioUsuario;
    private final ServicioTrans servicioTrans;
    private final String usuarioOrigen;
    private final String usuarioDestino;
    private final double monto;
    private final double comision;

    public TransferenciaCommand(ServicioUsuario servicioUsuario, ServicioTrans servicioTrans,
                              String usuarioOrigen, String usuarioDestino, double monto) {
        this.servicioUsuario = servicioUsuario;
        this.servicioTrans = servicioTrans;
        this.usuarioOrigen = usuarioOrigen;
        this.usuarioDestino = usuarioDestino;
        this.monto = monto;
        this.comision = monto * 0.05; //  comisión
    }
    @Override
    public void execute() {
        // 1. Debitar del origen (monto + comisión)
        servicioUsuario.actualizarSaldo(usuarioOrigen, -(monto + comision));
        
        // 2. Acreditar al destino (solo monto)
        servicioUsuario.actualizarSaldo(usuarioDestino, monto);
        
        // 3. Registrar transacción
        servicioTrans.registrarTransaccion(usuarioOrigen, "TRANSFERENCIA_INTERNACIONAL", monto + comision);
    }
    @Override
    public void undo() {
        // 1. Revertir en origen (acreditar monto + comisión)
        servicioUsuario.actualizarSaldo(usuarioOrigen, monto + comision);
        
        // 2. Revertir en destino (debitar monto)
        servicioUsuario.actualizarSaldo(usuarioDestino, -monto);
        
        // 3. Registrar transacción de reversa
        servicioTrans.registrarTransaccion(usuarioOrigen, "DESHACER TRANSFERENCIA", -(monto + comision));
    }
}