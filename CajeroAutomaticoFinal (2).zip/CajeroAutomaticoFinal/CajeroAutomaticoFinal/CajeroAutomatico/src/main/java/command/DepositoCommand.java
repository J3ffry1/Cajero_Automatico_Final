
package command;
import Modelo.ServicioUsuario;
import persistencia.ServicioTrans;


public class DepositoCommand implements Command {
    private final ServicioUsuario servicioUsuario;
    private final ServicioTrans servicioTrans;
    private final String usuario;
    private final double monto;
    
     public DepositoCommand(ServicioUsuario servicioUsuario, ServicioTrans servicioTrans, 
                         String usuario, double monto) {
        this.servicioUsuario = servicioUsuario;
        this.servicioTrans = servicioTrans;
        this.usuario = usuario;
        this.monto = monto;
    }
 @Override
    public void execute() {
        servicioUsuario.actualizarSaldo(usuario, monto);
        servicioTrans.registrarTransaccion(usuario, "DEPOSITO", monto);
    }

    @Override
    public void undo() {
        servicioUsuario.actualizarSaldo(usuario, -monto);
        servicioTrans.registrarTransaccion(usuario, "DESHACER DEPOSITO", -monto);
    }
}
