
package controlador;
import Modelo.ServicioUsuario;
import persistencia.ConexionMongo;

public class AutenticarControlador extends BaseControlador {
    public AutenticarControlador(ServicioUsuario servicioUsuario) {
        super(servicioUsuario);
    }    
    public boolean autenticar(String usuario, String contraseña) {
        return servicioUsuario.autenticarUsuario(usuario, contraseña);
    }
}
