package controlador.estrategias;

import Modelo.ResultadoOperacion;
import Modelo.ServicioUsuario;
import command.CommandHistory;
import command.DepositoCommand;
import persistencia.ServicioTrans;

public class EstrategiaDeposito implements OperacionBancaria {
    private final ServicioUsuario servicioUsuario;
    private final ServicioTrans transaccionServicio;
    private final CommandHistory commandHistory;
    private static final double LIMITE_DEPOSITO = 1000.00;

    public EstrategiaDeposito(ServicioUsuario servicioUsuario, ServicioTrans transaccionServicio) {
        this(servicioUsuario, transaccionServicio, new CommandHistory());
    }

    public EstrategiaDeposito(ServicioUsuario servicioUsuario, ServicioTrans transaccionServicio, 
                             CommandHistory commandHistory) {
        this.servicioUsuario = servicioUsuario;
        this.transaccionServicio = transaccionServicio;
        this.commandHistory = commandHistory;
    }

    @Override
    public ResultadoOperacion ejecutar(String usuario, double monto) {
        try {
            validarMontoPositivo(monto);
            validarLimiteDiario(monto);
            
            DepositoCommand command = new DepositoCommand(servicioUsuario, transaccionServicio, usuario, monto);
            command.execute();
            commandHistory.push(command);
            
            double nuevoSaldo = servicioUsuario.obtenerSaldo(usuario);
            return new ResultadoOperacion(true, "Depósito exitoso. Nuevo saldo: $" + nuevoSaldo);
        } catch (DepositoException e) {
            return new ResultadoOperacion(false, e.getMessage());
        }
    }

    @Override
    public boolean puedeDeshacer() {
        return commandHistory.canUndo();
    }

    @Override
    public boolean puedeRehacer() {
        return commandHistory.canRedo();
    }

    @Override
    public void deshacer() {
        commandHistory.undo();
    }

    @Override
    public void rehacer() {
        commandHistory.redo();
    }

    private void validarMontoPositivo(double monto) throws DepositoException {
        if (monto <= 0) {
            throw new DepositoException("El monto debe ser mayor a cero");
        }
    }

    private void validarLimiteDiario(double monto) throws DepositoException {
        if (monto > LIMITE_DEPOSITO) {
            throw new DepositoException("Excede el límite diario de depósito ($" + LIMITE_DEPOSITO + ")");
        }
    }

    public static class DepositoException extends Exception {
        public DepositoException(String mensaje) {
            super(mensaje);
        }
    }
}