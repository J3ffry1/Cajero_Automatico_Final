package controlador;
// implementado
import Modelo.ResultadoOperacion;
import Modelo.ServicioUsuario;
import controlador.estrategias.EstrategiaDeposito;
import controlador.estrategias.OperacionBancaria;
import persistencia.ServicioTrans;

public class DepositoControlador {
    private final OperacionBancaria estrategiaDeposito;

    public DepositoControlador(ServicioUsuario servicioUsuario, ServicioTrans transaccionServicio) {
        this.estrategiaDeposito = new EstrategiaDeposito(servicioUsuario, transaccionServicio);
    }

    public DepositoControlador(ServicioUsuario servicioUsuario, ServicioTrans transaccionServicio, 
                             OperacionBancaria estrategia) {
        this.estrategiaDeposito = estrategia; // Para testing con mock
    }

    public ResultadoOperacion realizarDeposito(String usuario, double monto) {
        return estrategiaDeposito.ejecutar(usuario, monto);
    }

    public boolean puedeDeshacer() {
        return estrategiaDeposito.puedeDeshacer();
    }

    public boolean puedeRehacer() {
        return estrategiaDeposito.puedeRehacer();
    }

    public void deshacer() {
        estrategiaDeposito.deshacer();
    }

    public void rehacer() {
        estrategiaDeposito.rehacer();
    }
}

