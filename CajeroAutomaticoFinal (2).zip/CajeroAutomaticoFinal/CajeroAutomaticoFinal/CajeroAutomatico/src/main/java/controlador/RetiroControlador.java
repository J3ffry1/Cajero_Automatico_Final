
package controlador;

import Modelo.ResultadoOperacion;
import Modelo.ServicioUsuario;
import controlador.estrategias.EstrategiaRetiro;
import controlador.estrategias.OperacionBancaria;
import persistencia.ServicioTrans;

public class RetiroControlador {
    private final OperacionBancaria estrategiaRetiro;

    public RetiroControlador(ServicioUsuario servicioUsuario, ServicioTrans transaccionServicio) {
        this.estrategiaRetiro = new EstrategiaRetiro(servicioUsuario, transaccionServicio);
    }

    public RetiroControlador(ServicioUsuario servicioUsuario, ServicioTrans transaccionServicio,
                           OperacionBancaria estrategia) {
        this.estrategiaRetiro = estrategia; // Para testing con mock
    }

    public ResultadoOperacion realizarRetiro(String usuario, double monto) {
        return estrategiaRetiro.ejecutar(usuario, monto);
    }

    public boolean puedeDeshacer() {
        return estrategiaRetiro.puedeDeshacer();
    }

    public boolean puedeRehacer() {
        return estrategiaRetiro.puedeRehacer();
    }

    public void deshacer() {
        estrategiaRetiro.deshacer();
    }

    public void rehacer() {
        estrategiaRetiro.rehacer();
    }
}