
package controlador;
import Modelo.ServicioUsuario;
    public abstract class BaseControlador {
    protected final ServicioUsuario servicioUsuario;
    public BaseControlador(ServicioUsuario servicioUsuario) {
        this.servicioUsuario = servicioUsuario;
    }    
  }
