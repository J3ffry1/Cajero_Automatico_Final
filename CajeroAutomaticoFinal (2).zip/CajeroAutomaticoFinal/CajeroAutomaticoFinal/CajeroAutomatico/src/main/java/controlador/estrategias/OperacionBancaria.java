
package controlador.estrategias;
import Modelo.ResultadoOperacion;

public interface OperacionBancaria {
   ResultadoOperacion ejecutar(String usuario, double monto);
    boolean puedeDeshacer();
    boolean puedeRehacer();
    void deshacer();
    void rehacer();
    
}
