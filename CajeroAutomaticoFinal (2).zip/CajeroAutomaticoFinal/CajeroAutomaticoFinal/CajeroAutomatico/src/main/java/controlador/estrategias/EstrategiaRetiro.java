
package controlador.estrategias;

import Modelo.ResultadoOperacion;
import Modelo.ServicioUsuario;
import command.CommandHistory;
import command.RetiroCommand;
import persistencia.ServicioTrans;

public class EstrategiaRetiro implements OperacionBancaria {
    private final ServicioUsuario servicioUsuario;
    private final ServicioTrans transaccionServicio;
    private final CommandHistory commandHistory;
    public static final double LIMITE_RETIRO = 1000.00;

    public EstrategiaRetiro(ServicioUsuario servicioUsuario, ServicioTrans transaccionServicio) {
        this(servicioUsuario, transaccionServicio, new CommandHistory());
    }

    public EstrategiaRetiro(ServicioUsuario servicioUsuario, ServicioTrans transaccionServicio,
                          CommandHistory commandHistory) {
        this.servicioUsuario = servicioUsuario;
        this.transaccionServicio = transaccionServicio;
        this.commandHistory = commandHistory;
    }

    @Override
    public ResultadoOperacion ejecutar(String usuario, double monto) {
        try {
            validarMontoPositivo(monto);
            validarSaldoSuficiente(usuario, monto);
            validarLimiteDiario(monto);

            RetiroCommand command = new RetiroCommand(servicioUsuario, transaccionServicio, usuario, monto);
            command.execute();
            commandHistory.push(command);
            
            double nuevoSaldo = servicioUsuario.obtenerSaldo(usuario);
            return new ResultadoOperacion(true, "Retiro exitoso. Nuevo saldo: $" + nuevoSaldo);
            
        } catch (RetiroException e) {
            return new ResultadoOperacion(false, e.getMessage());
        }
    }

    @Override
    public boolean puedeDeshacer() {
        return commandHistory.canUndo();
    }

    @Override
    public boolean puedeRehacer() {
        return commandHistory.canRedo();
    }

    @Override
    public void deshacer() {
        commandHistory.undo();
    }

    @Override
    public void rehacer() {
        commandHistory.redo();
    }

    private void validarMontoPositivo(double monto) throws RetiroException {
        if (monto <= 0) {
            throw new RetiroException("El monto debe ser mayor a cero");
        }
    }

    private void validarSaldoSuficiente(String usuario, double monto) throws RetiroException {
        double saldo = servicioUsuario.obtenerSaldo(usuario);
        if (monto > saldo) {
            throw new RetiroException("Saldo insuficiente. Saldo actual: $" + saldo);
        }
    }

    private void validarLimiteDiario(double monto) throws RetiroException {
        if (monto > LIMITE_RETIRO) {
            throw new RetiroException("Excede el límite diario de retiro ($" + LIMITE_RETIRO + ")");
        }
    }
public double getLimiteRetiro() {
    return LIMITE_RETIRO;
}
    public static class RetiroException extends Exception {
        public RetiroException(String mensaje) {
            super(mensaje);
        }
    }
}