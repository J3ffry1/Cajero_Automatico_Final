
package controlador;

import Modelo.ServicioUsuario;
import Vista.CajeroOpcion;
import Vista.PersonalVentanilla;
import persistencia.ServicioTrans;


public class PrincipalControlador {
    private final ServicioUsuario servicioUsuario;
    private final ServicioTrans servicioTrans;
    public final MenuControlador menuControlador;
     public final PersonalVenContro ventanillaControlador;

    public PrincipalControlador(ServicioUsuario servicioUsuario, ServicioTrans servicioTrans) {
        if (servicioUsuario == null || servicioTrans == null) {
            throw new IllegalArgumentException("Los servicios no pueden ser nulos");
        }
        this.servicioUsuario = servicioUsuario;
        this.servicioTrans = servicioTrans;
        this.menuControlador = new MenuControlador(servicioUsuario, servicioTrans);
        this.ventanillaControlador = new PersonalVenContro(servicioUsuario, servicioTrans);
    }

   public void abrirVentanilla(String usuario) {
        validarUsuario(usuario);
        try {
             new PersonalVentanilla(usuario, ventanillaControlador).setVisible(true);
        } catch (Exception e) {
            throw new RuntimeException("Error al abrir ventanilla: " + e.getMessage(), e);
        }
    }
    public void abrirCajero(String usuario) {
        validarUsuario(usuario);
        try {
            CajeroOpcion cajero = new CajeroOpcion(menuControlador, usuario);
            cajero.setVisible(true);
        } catch (Exception e) {
            throw new RuntimeException("Error al abrir cajero: " + e.getMessage(), e);
        }
    }

    private void validarUsuario(String usuario) {
        if (usuario == null || usuario.trim().isEmpty()) {
            throw new IllegalArgumentException("El usuario no puede ser nulo o vacío");
        }
    }
}
