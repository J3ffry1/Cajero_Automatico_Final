
package controlador;

import Modelo.ServicioUsuario;
import Vista.MenuOperaciones;
import Vista.MenuOperaciones2;
import Vista.MenuOperaciones3;
import persistencia.ServicioTrans;

public class PersonalVenContro {
    private final ServicioUsuario servicioUsuario;
    private final ServicioTrans servicioTrans;

    public PersonalVenContro(ServicioUsuario servicioUsuario, ServicioTrans servicioTrans) {
        this.servicioUsuario = servicioUsuario;
        this.servicioTrans = servicioTrans;
    }
    
public void abrirMenuOperaciones(String usuario, int cajero) {
    switch(cajero) {
        case 1:
            MenuControlador menuCtrl = new MenuControlador(servicioUsuario, servicioTrans);
            new MenuOperaciones(usuario, menuCtrl).setVisible(true);
            break;
        case 2:
            MenuControlador menuCtrl2 = new MenuControlador(servicioUsuario, servicioTrans);
            new MenuOperaciones2(usuario, menuCtrl2).setVisible(true);
            break;
        case 3:
            MenuControlador menuCtrl3 = new MenuControlador(servicioUsuario, servicioTrans);
            new MenuOperaciones3(usuario, menuCtrl3).setVisible(true);
            break;
        default:
            throw new IllegalArgumentException("Cajero no válido");
    }
}
}
