
package controlador.estrategias;

import Modelo.ResultadoOperacion;
import Modelo.ServicioUsuario;
import command.CommandHistory;
import command.TransferenciaCommand;
import persistencia.ServicioTrans;

public class EstrategiaTransferencia implements OperacionBancaria {
    private final ServicioUsuario servicioUsuario;
    private final ServicioTrans transaccionServicio;
    private final CommandHistory commandHistory;
    private static final double COMISION = 0.05; // 5% de comisión
    
    public EstrategiaTransferencia(ServicioUsuario servicioUsuario, ServicioTrans transaccionServicio) {
        this(servicioUsuario, transaccionServicio, new CommandHistory());
    }
    
    public EstrategiaTransferencia(ServicioUsuario servicioUsuario, ServicioTrans transaccionServicio, 
                                 CommandHistory commandHistory) {
        if (servicioUsuario == null || transaccionServicio == null) {
            throw new IllegalArgumentException("Los servicios no pueden ser nulos");
        }
        this.servicioUsuario = servicioUsuario;
        this.transaccionServicio = transaccionServicio;
        this.commandHistory = commandHistory;
    }

    @Override
    public ResultadoOperacion ejecutar(String usuarioOrigen, double monto) {
        // Este método no se usa para transferencias que requieren cuenta destino
        return new ResultadoOperacion(false, "Método no soportado para transferencias internacionales");
    }

    public ResultadoOperacion ejecutar(String usuarioOrigen, String cuentaDestino, double monto) {
        try {
            // 1. Validar campos
            validarCampos(usuarioOrigen, cuentaDestino, monto);
            
            // 2. Validar cuenta destino
            validarCuentaDestino(cuentaDestino);
            
            // 3. Validar no es transferencia a sí mismo
            validarNoAutotransferencia(usuarioOrigen, cuentaDestino);
            
            // 4. Validar monto positivo
            validarMontoPositivo(monto);
            
            // 5. Calcular comisión y total
            double comision = calcularComision(monto);
            double total = monto + comision;
            
            // 6. Validar saldo suficiente
            validarSaldoSuficiente(usuarioOrigen, total);
            
            // Crear y ejecutar comando
            TransferenciaCommand command = new TransferenciaCommand(
                servicioUsuario, 
                transaccionServicio,
                usuarioOrigen,
                cuentaDestino,
                monto);
            command.execute();
            commandHistory.push(command);
            
            String nombreDestinatario = servicioUsuario.obtenerNombreCuenta(cuentaDestino);
            double nuevoSaldo = servicioUsuario.obtenerSaldo(usuarioOrigen);
            
            String mensaje = String.format(
                "Transferencia internacional exitosa!%n%n" +
                "Destinatario: %s%n" +
                "Cuenta destino: %s%n" +
                "Monto enviado: $%.2f%n" +
                "Comisión (5%%): $%.2f%n" +
                "Total debitado: $%.2f%n" +
                "Nuevo saldo: $%.2f",
                nombreDestinatario, cuentaDestino, monto, comision, total, nuevoSaldo);
            
            return new ResultadoOperacion(true, mensaje);
            
        } catch (TransferenciaException e) {
            return new ResultadoOperacion(false, e.getMessage());
        } catch (Exception e) {
            return new ResultadoOperacion(false, 
                "Error inesperado al realizar la transferencia: " + e.getMessage());
        }
    }

    @Override
    public boolean puedeDeshacer() {
        return commandHistory.canUndo();
    }

    @Override
    public boolean puedeRehacer() {
        return commandHistory.canRedo();
    }

    @Override
    public void deshacer() {
        commandHistory.undo();
    }

    @Override
    public void rehacer() {
        commandHistory.redo();
    }
    
    // ========== MÉTODOS DE VALIDACIÓN ========== //
    private void validarCampos(String cuentaOrigen, String cuentaDestino, double monto) 
            throws TransferenciaException {
        if (cuentaOrigen == null || cuentaDestino == null || 
            cuentaOrigen.isEmpty() || cuentaDestino.isEmpty()) {
            throw new TransferenciaException("Todos los campos son obligatorios");
        }
    }
    
    private void validarCuentaDestino(String cuentaDestino) throws TransferenciaException {
        if (!servicioUsuario.verificarCuentaExistente(cuentaDestino)) {
            throw new TransferenciaException("La cuenta destino no existe en nuestro sistema");
        }
    }
    
    private void validarNoAutotransferencia(String cuentaOrigen, String cuentaDestino) 
            throws TransferenciaException {
        if (cuentaOrigen.equals(cuentaDestino)) {
            throw new TransferenciaException("No puede transferir a su propia cuenta");
        }
    }
    
    private void validarMontoPositivo(double monto) throws TransferenciaException {
        if (monto <= 0) {
            throw new TransferenciaException("El monto debe ser mayor a cero");
        }
    }
    
    private double calcularComision(double monto) {
        return monto * COMISION;
    }
    
    private void validarSaldoSuficiente(String cuentaOrigen, double total) throws TransferenciaException {
        double saldoActual = servicioUsuario.obtenerSaldo(cuentaOrigen);
        if (total > saldoActual) {
            throw new TransferenciaException(String.format(
                "Saldo insuficiente para cubrir la transferencia + comisión%n" +
                "Total requerido: $%.2f%n" +
                "Su saldo actual: $%.2f", 
                total, saldoActual));
        }
    }

    public static class TransferenciaException extends Exception {
        public TransferenciaException(String mensaje) {
            super(mensaje);
        }
    }
}