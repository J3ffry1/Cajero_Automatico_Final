package controlador;

import Modelo.ResultadoOperacion;
import Modelo.ServicioUsuario;
import controlador.estrategias.EstrategiaTransferencia;
import controlador.estrategias.OperacionBancaria;
import persistencia.ServicioTrans;

public class TransIContro {
    private final EstrategiaTransferencia estrategiaTransferencia;

    public TransIContro(ServicioUsuario servicioUsuario, ServicioTrans transaccionServicio) {
        this.estrategiaTransferencia = new EstrategiaTransferencia(servicioUsuario, transaccionServicio);
    }

    public TransIContro(ServicioUsuario servicioUsuario, ServicioTrans transaccionServicio,
                       EstrategiaTransferencia estrategia) {
        this.estrategiaTransferencia = estrategia; // Para testing con mock
    }

    public ResultadoOperacion realizarTransferencia(String usuarioOrigen, String cuentaDestino, double monto) {
        return estrategiaTransferencia.ejecutar(usuarioOrigen, cuentaDestino, monto);
    }

    public boolean puedeDeshacer() {
        return estrategiaTransferencia.puedeDeshacer();
    }

    public boolean puedeRehacer() {
        return estrategiaTransferencia.puedeRehacer();
    }

    public void deshacer() {
        estrategiaTransferencia.deshacer();
    }

    public void rehacer() {
        estrategiaTransferencia.rehacer();
    }
}