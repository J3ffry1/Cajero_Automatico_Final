package controlador;


import Modelo.ServicioUsuario;
import Vista.CajeroOpcion;
import Vista.CajeroRetiro;
import Vista.DepositoFrame;
import Vista.Inicio;
import Vista.TransferenciaInternacionalFrame;
import javax.swing.JFrame;
import persistencia.ServicioTrans;

public class MenuControlador {
    private final ServicioUsuario servicioUsuario;
    private final ServicioTrans servicioTrans;

    public MenuControlador(ServicioUsuario servicioUsuario, ServicioTrans servicioTrans) {
        if (servicioUsuario == null || servicioTrans == null) {
            throw new IllegalArgumentException("Los servicios no pueden ser nulos");
        }
        this.servicioUsuario = servicioUsuario;
        this.servicioTrans = servicioTrans;
    }

    public double obtenerSaldo(String usuario) {
        return servicioUsuario.obtenerSaldo(usuario);
    }

    public String obtenerHistorial(String usuario) {
        return servicioTrans.obtenerHistorial(usuario);
    }

    public void abrirVentanaRetiro(String usuario) {
        RetiroControlador retiroCtrl = new RetiroControlador(servicioUsuario, servicioTrans);
        new CajeroRetiro(retiroCtrl, usuario,this).setVisible(true);
    }

    public void abrirVentanaDeposito(String usuario) {
        DepositoControlador depositoCtrl = new DepositoControlador(servicioUsuario, servicioTrans);
        new DepositoFrame(usuario, depositoCtrl,this).setVisible(true);
    }

    public void abrirVentanaTransferencia(String usuario) {
        TransIContro transferenciaCtrl = new TransIContro(servicioUsuario, servicioTrans);
        new TransferenciaInternacionalFrame(usuario, transferenciaCtrl,this).setVisible(true);
    }

    public void cerrarSesion() {
        new Inicio(new InicioControlador(servicioUsuario, servicioTrans)).setVisible(true);
    }
    public void cerrarSesion(JFrame ventanaActual) {
        // Cierra la ventana actual
        ventanaActual.dispose();
        
        // Muestra la ventana de inicio de sesión
        new Inicio(new InicioControlador(servicioUsuario, servicioTrans)).setVisible(true);
    }
    
     public void regresarAMenu(JFrame ventanaActual, String usuario) {
        ventanaActual.dispose();
        new CajeroOpcion(this, usuario).setVisible(true);
    }
    
}
