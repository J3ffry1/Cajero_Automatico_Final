
package controlador;

import Modelo.ServicioUsuario;
import Vista.Inicio;
import persistencia.ServicioTrans;
import Vista.Principal;

public class InicioControlador {
    private final ServicioUsuario servicioUsuario;
    private final ServicioTrans servicioTrans;
    private Inicio vistaInicio; // Referencia a la vista de inicio

    public InicioControlador(ServicioUsuario servicioUsuario, ServicioTrans servicioTrans) {
        if (servicioUsuario == null || servicioTrans == null) {
            throw new IllegalArgumentException("Los servicios no pueden ser nulos");
        }
        this.servicioUsuario = servicioUsuario;
        this.servicioTrans = servicioTrans;
        
    }
public void setVistaInicio(Inicio vista) {
        this.vistaInicio = vista;
    }
    public boolean autenticarUsuario(String usuario, String contrasena) {
        if (usuario == null || usuario.trim().isEmpty() || contrasena == null || contrasena.trim().isEmpty()) {
            throw new IllegalArgumentException("Usuario y contraseña son requeridos");
        }
        return servicioUsuario.autenticarUsuario(usuario, contrasena);
    }
   public void mostrarVentanaInicio() {
        if (vistaInicio == null) {
            vistaInicio = new Inicio(this);
        }
        vistaInicio.setVisible(true);
    }
    public void inicioSesionExitoso(String usuario) {
        try {
            MenuControlador menuControlador = new MenuControlador(servicioUsuario, servicioTrans);
            PrincipalControlador principalControlador = new PrincipalControlador(servicioUsuario, servicioTrans);
            
            Principal principalView = new Principal(usuario, principalControlador);
            principalView.setVisible(true);
        } catch (Exception e) {
            throw new RuntimeException("Error al iniciar sesión: " + e.getMessage(), e);
        }
    }
}

