package com.mycompany.cajeroautomatico;

import org.junit.jupiter.api.*;
import java.io.*;
import java.nio.file.*;

import static org.junit.jupiter.api.Assertions.*;
import persistencia.LeerHistorial;

class LeerHistorialTest {

    private static final String ARCHIVO_TEST = "historial_test.csv";

    @AfterEach
    void limpiarArchivo() throws IOException {
        Files.deleteIfExists(Path.of(ARCHIVO_TEST));
    }

    @Test
    void testConstructorPorDefecto() {
        LeerHistorial lh = new LeerHistorial();
        assertNotNull(lh);
    }

    @Test
    void testConstructorConRuta() {
        LeerHistorial lh = new LeerHistorial(ARCHIVO_TEST);
        assertNotNull(lh);
    }

    @Test
    void testArchivoNoExiste() {
        LeerHistorial lh = new LeerHistorial("archivo_inexistente.csv");
        String resultado = lh.leerHistorial("usuario");
        assertEquals("No hay historial de transacciones disponible", resultado);
    }

    @Test
    void testSinTransaccionesParaUsuario() throws IOException {
        Files.write(Path.of(ARCHIVO_TEST), """
                usuario,tipo,monto,fecha
                otro,DEPOSITO,100,2025-08-01 12:00:00
                """.getBytes());

        LeerHistorial lh = new LeerHistorial(ARCHIVO_TEST);
        String resultado = lh.leerHistorial("usuario");
        assertEquals("No hay transacciones registradas", resultado);
    }

 

    @Test
    void testLineaMalFormadaIgnorada() throws IOException {
        Files.write(Path.of(ARCHIVO_TEST), """
                usuario,tipo,monto,fecha
                jeffry,DEPOSITO,100.0,2025-08-01 12:00:00
                jeffry,MALFORMADA
                """.getBytes());

        LeerHistorial lh = new LeerHistorial(ARCHIVO_TEST);
        String resultado = lh.leerHistorial("jeffry");

        assertTrue(resultado.contains("DEPOSITO"));
        assertFalse(resultado.contains("MALFORMADA"));
    }

  



   
}
