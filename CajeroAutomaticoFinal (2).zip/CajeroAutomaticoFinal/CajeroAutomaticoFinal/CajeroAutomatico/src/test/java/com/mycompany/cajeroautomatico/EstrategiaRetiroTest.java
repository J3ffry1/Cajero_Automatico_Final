
package com.mycompany.cajeroautomatico;


import Modelo.ResultadoOperacion;
import Modelo.ServicioUsuario;
import command.CommandHistory;
import command.RetiroCommand;
import controlador.estrategias.EstrategiaRetiro;
import persistencia.ServicioTrans;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

 class EstrategiaRetiroTest {
    private static final double LIMITE_RETIRO = 1000.00;

    @Mock
    private ServicioUsuario servicioUsuarioMock;
    
    @Mock
    private ServicioTrans servicioTransMock;
    
    @Mock
    private CommandHistory commandHistoryMock;
    
    @Mock
    private RetiroCommand retiroCommandMock;
    
    private EstrategiaRetiro estrategiaRetiro;


    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        estrategiaRetiro = new EstrategiaRetiro(servicioUsuarioMock, servicioTransMock, commandHistoryMock);
    }



    @Test
    void ejecutar_Falla_CuandoMontoEsNegativo() {
        String usuario = "user1";
        double montoInvalido = -100.0;
        
        ResultadoOperacion resultado = estrategiaRetiro.ejecutar(usuario, montoInvalido);
        
        assertAll(
            () -> assertFalse(resultado.isExito()),
            () -> assertEquals("El monto debe ser mayor a cero", resultado.getMensaje()),
            () -> verifyNoInteractions(commandHistoryMock)
        );
    }

    @Test
    void ejecutar_Falla_CuandoSaldoInsuficiente() {
        String usuario = "user1";
        double monto = 500.0;
        double saldoInsuficiente = 300.0;
        
        when(servicioUsuarioMock.obtenerSaldo(usuario)).thenReturn(saldoInsuficiente);
        
        ResultadoOperacion resultado = estrategiaRetiro.ejecutar(usuario, monto);
        
        assertAll(
            () -> assertFalse(resultado.isExito()),
            () -> assertTrue(resultado.getMensaje().contains("Saldo insuficiente")),
            () -> verify(servicioUsuarioMock).obtenerSaldo(usuario),
            () -> verifyNoInteractions(commandHistoryMock)
        );
    }

    @Test
    void ejecutar_Falla_CuandoExcedeLimiteDiario() {
        String usuario = "user1";
        double montoExcesivo = LIMITE_RETIRO + 100.0;
        double saldoSuficiente = montoExcesivo + 500.0;
        
        when(servicioUsuarioMock.obtenerSaldo(usuario)).thenReturn(saldoSuficiente);
        
        ResultadoOperacion resultado = estrategiaRetiro.ejecutar(usuario, montoExcesivo);
        
        assertAll(
            () -> assertFalse(resultado.isExito()),
            () -> assertTrue(resultado.getMensaje().contains("Excede el límite diario")),
            () -> verify(servicioUsuarioMock).obtenerSaldo(usuario),
            () -> verifyNoInteractions(commandHistoryMock)
        );
    }

    @Test
    void puedeDeshacer_RetornaTrue_CuandoHayComandos() {
        when(commandHistoryMock.canUndo()).thenReturn(true);
        assertTrue(estrategiaRetiro.puedeDeshacer());
        verify(commandHistoryMock).canUndo();
    }

    @Test
    void puedeRehacer_RetornaTrue_CuandoHayComandos() {
        when(commandHistoryMock.canRedo()).thenReturn(true);
        assertTrue(estrategiaRetiro.puedeRehacer());
        verify(commandHistoryMock).canRedo();
    }

    @Test
    void deshacer_EjecutaUndoEnCommandHistory() {
        estrategiaRetiro.deshacer();
        verify(commandHistoryMock).undo();
    }

    @Test
    void rehacer_EjecutaRedoEnCommandHistory() {
        estrategiaRetiro.rehacer();
        verify(commandHistoryMock).redo();
    }

    @Test
    void constructorDefault_CreaCommandHistoryInterno() {
        EstrategiaRetiro estrategia = new EstrategiaRetiro(servicioUsuarioMock, servicioTransMock);
        assertNotNull(estrategia);
        // Verificación implícita de que no lanza excepciones
    }
}