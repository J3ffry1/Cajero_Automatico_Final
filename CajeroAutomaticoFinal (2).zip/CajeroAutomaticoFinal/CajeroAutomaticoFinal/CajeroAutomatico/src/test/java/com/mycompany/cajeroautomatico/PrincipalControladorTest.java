package com.mycompany.cajeroautomatico;

import controlador.PrincipalControlador;
import Modelo.ServicioUsuario;
import controlador.MenuControlador;
import controlador.PersonalVenContro;
import persistencia.ServicioTrans;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class PrincipalControladorTest {

    @Mock
    private ServicioUsuario servicioUsuarioMock;

    @Mock
    private ServicioTrans servicioTransMock;

    @Mock
    private PersonalVenContro ventanillaControladorMock;

    @Mock
    private MenuControlador menuControladorMock;

    private PrincipalControlador principalControlador;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        principalControlador = new PrincipalControlador(servicioUsuarioMock, servicioTransMock) {
            protected PersonalVenContro createVentanillaController() {
                return ventanillaControladorMock;
            }

            protected MenuControlador createMenuController() {
                return menuControladorMock;
            }
        };
    }

    @Test
    void testConstructor_ServiciosNulos_LanzaIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, () -> 
            new PrincipalControlador(null, servicioTransMock));
        assertThrows(IllegalArgumentException.class, () -> 
            new PrincipalControlador(servicioUsuarioMock, null));
    }

    @Test
    void testAbrirVentanilla_UsuarioValido_NoLanzaExcepcion() {
        assertDoesNotThrow(() -> 
            principalControlador.abrirVentanilla("usuarioValido"));
    }

    @Test
    void testAbrirVentanilla_UsuarioNulo_LanzaExcepcion() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> 
            principalControlador.abrirVentanilla(null));
        assertEquals("El usuario no puede ser nulo o vacío", exception.getMessage());
    }

    @Test
    void testAbrirVentanilla_UsuarioVacio_LanzaExcepcion() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> 
            principalControlador.abrirVentanilla("   "));
        assertEquals("El usuario no puede ser nulo o vacío", exception.getMessage());
    }

    @Test
    void testAbrirCajero_UsuarioValido_NoLanzaExcepcion() {
        assertDoesNotThrow(() -> 
            principalControlador.abrirCajero("usuarioValido"));
    }

    @Test
    void testAbrirCajero_UsuarioNulo_LanzaExcepcion() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> 
            principalControlador.abrirCajero(null));
        assertEquals("El usuario no puede ser nulo o vacío", exception.getMessage());
    }

    @Test
    void testAbrirCajero_UsuarioVacio_LanzaExcepcion() {
        Exception exception = assertThrows(IllegalArgumentException.class, () -> 
            principalControlador.abrirCajero("   "));
        assertEquals("El usuario no puede ser nulo o vacío", exception.getMessage());
    }
}
