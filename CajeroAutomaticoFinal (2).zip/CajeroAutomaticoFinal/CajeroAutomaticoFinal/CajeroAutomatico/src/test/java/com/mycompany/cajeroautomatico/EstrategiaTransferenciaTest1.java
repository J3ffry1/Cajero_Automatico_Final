package com.mycompany.cajeroautomatico;

import controlador.estrategias.EstrategiaTransferencia;
import Modelo.ResultadoOperacion;
import Modelo.ServicioUsuario;
import command.CommandHistory;
import command.TransferenciaCommand;
import persistencia.ServicioTrans;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class EstrategiaTransferenciaTest1 {

    @Mock
    private ServicioUsuario servicioUsuarioMock;

    @Mock
    private ServicioTrans servicioTransMock;

    @Mock
    private CommandHistory commandHistoryMock;

    private EstrategiaTransferencia estrategiaTransferencia;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        estrategiaTransferencia = new EstrategiaTransferencia(servicioUsuarioMock, servicioTransMock, commandHistoryMock);
    }

    @Test
    void testConstructor_ServiciosNulos_LanzaIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, () -> 
            new EstrategiaTransferencia(null, servicioTransMock));
        assertThrows(IllegalArgumentException.class, () -> 
            new EstrategiaTransferencia(servicioUsuarioMock, null));
    }

    @Test
    void testEjecutar_TransferenciaExitosa() throws Exception {
        String usuarioOrigen = "usuarioOrigen";
        String cuentaDestino = "cuentaDestino";
        double monto = 100.0;

        when(servicioUsuarioMock.verificarCuentaExistente(cuentaDestino)).thenReturn(true);
        when(servicioUsuarioMock.obtenerSaldo(usuarioOrigen)).thenReturn(200.0);
        when(servicioUsuarioMock.obtenerNombreCuenta(cuentaDestino)).thenReturn("Nombre Destinatario");

        ResultadoOperacion resultado = estrategiaTransferencia.ejecutar(usuarioOrigen, cuentaDestino, monto);

        assertTrue(resultado.isExito());
        assertTrue(resultado.getMensaje().contains("Transferencia internacional exitosa!"));
        verify(commandHistoryMock).push(any(TransferenciaCommand.class));
    }

    @Test
    void testEjecutar_CuentaDestinoNoExistente_LanzaTransferenciaException() {
        String usuarioOrigen = "usuarioOrigen";
        String cuentaDestino = "cuentaDestino";
        double monto = 100.0;

        when(servicioUsuarioMock.verificarCuentaExistente(cuentaDestino)).thenReturn(false);

        ResultadoOperacion resultado = estrategiaTransferencia.ejecutar(usuarioOrigen, cuentaDestino, monto);

        assertFalse(resultado.isExito());
        assertEquals("La cuenta destino no existe en nuestro sistema", resultado.getMensaje());
    }

    @Test
    void testEjecutar_SaldoInsuficiente_LanzaTransferenciaException() {
        String usuarioOrigen = "usuarioOrigen";
        String cuentaDestino = "cuentaDestino";
        double monto = 100.0;

        when(servicioUsuarioMock.verificarCuentaExistente(cuentaDestino)).thenReturn(true);
        when(servicioUsuarioMock.obtenerSaldo(usuarioOrigen)).thenReturn(50.0); // Saldo insuficiente

        ResultadoOperacion resultado = estrategiaTransferencia.ejecutar(usuarioOrigen, cuentaDestino, monto);

        assertFalse(resultado.isExito());
        assertTrue(resultado.getMensaje().contains("Saldo insuficiente para cubrir la transferencia + comisión"));
    }

    @Test
    void testEjecutar_MontoNegativo_LanzaTransferenciaException() {
        String usuarioOrigen = "usuarioOrigen";
        String cuentaDestino = "cuentaDestino";
        double monto = -50.0; // Monto inválido

        ResultadoOperacion resultado = estrategiaTransferencia.ejecutar(usuarioOrigen, cuentaDestino, monto);

        assertFalse(resultado.isExito());
        assertEquals("El monto debe ser mayor a cero", resultado.getMensaje());
    }

    @Test
    void testEjecutar_Autotransferencia_LanzaTransferenciaException() {
        String usuarioOrigen = "usuarioOrigen";
        String cuentaDestino = "usuarioOrigen"; // Mismo usuario

        ResultadoOperacion resultado = estrategiaTransferencia.ejecutar(usuarioOrigen, cuentaDestino, 100.0);

        assertFalse(resultado.isExito());
        assertEquals("No puede transferir a su propia cuenta", resultado.getMensaje());
    }
}
