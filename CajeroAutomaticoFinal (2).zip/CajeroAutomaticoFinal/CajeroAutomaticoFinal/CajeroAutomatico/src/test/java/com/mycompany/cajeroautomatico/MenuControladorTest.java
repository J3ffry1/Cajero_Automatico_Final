package com.mycompany.cajeroautomatico;

import controlador.MenuControlador;
import Modelo.ServicioUsuario;
import persistencia.ServicioTrans;
import Vista.CajeroRetiro;
import Vista.DepositoFrame;
import Vista.TransferenciaInternacionalFrame;
import Vista.Inicio;
import Vista.Principal;
import controlador.DepositoControlador;
import controlador.RetiroControlador;
import controlador.TransIContro;
import controlador.InicioControlador;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.MockedConstruction;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
import Modelo.ServicioUsuario;
import persistencia.ServicioTrans;
import Vista.Principal; // Asegúrate de importar la vista correcta
import controlador.MenuControlador;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

public class MenuControladorTest {
@Mock
    private ServicioUsuario servicioUsuario;
    @Mock
    private ServicioUsuario servicioUsuarioMock;
    @Mock
    private ServicioTrans servicioTransMock;

    private MenuControlador menuControlador;
 @Mock
    private Principal principalView; // Mock de la vista
    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        menuControlador = new MenuControlador(servicioUsuarioMock, servicioTransMock);
    }

    @Test
    void testConstructor_serviciosNulos_lanzaExcepcion() {
        assertThrows(IllegalArgumentException.class, () -> new MenuControlador(null, servicioTransMock));
        assertThrows(IllegalArgumentException.class, () -> new MenuControlador(servicioUsuarioMock, null));
    }

    @Test
    void testObtenerSaldo() {
        String usuario = "testUser";
        double saldoEsperado = 1500.0;
        when(servicioUsuarioMock.obtenerSaldo(usuario)).thenReturn(saldoEsperado);

        double saldoActual = menuControlador.obtenerSaldo(usuario);
        assertEquals(saldoEsperado, saldoActual);
        verify(servicioUsuarioMock).obtenerSaldo(usuario);
    }

    @Test
    void testObtenerHistorial() {
        String usuario = "testUser";
        String historialEsperado = "Historial de prueba";
        when(servicioTransMock.obtenerHistorial(usuario)).thenReturn(historialEsperado);

        String historialActual = menuControlador.obtenerHistorial(usuario);
        assertEquals(historialEsperado, historialActual);
        verify(servicioTransMock).obtenerHistorial(usuario);
    }

    @Test
    void testAbrirVentanaRetiro() {
        String usuario = "testUser";
        try (MockedConstruction<CajeroRetiro> mocked = mockConstruction(CajeroRetiro.class)) {
            menuControlador.abrirVentanaRetiro(usuario);
            verify(mocked.constructed().get(0)).setVisible(true);
            // También puedes verificar que se construyó con los argumentos correctos
            // verify(mocked.constructed().get(0)).<init>(any(RetiroControlador.class), eq(usuario));
        }
    }

    @Test
    void testAbrirVentanaDeposito() {
        String usuario = "testUser";
        try (MockedConstruction<DepositoFrame> mocked = mockConstruction(DepositoFrame.class)) {
            menuControlador.abrirVentanaDeposito(usuario);
            verify(mocked.constructed().get(0)).setVisible(true);
        }
    }

    @Test
    void testAbrirVentanaTransferencia() {
        String usuario = "testUser";
        try (MockedConstruction<TransferenciaInternacionalFrame> mocked = mockConstruction(TransferenciaInternacionalFrame.class)) {
            menuControlador.abrirVentanaTransferencia(usuario);
            verify(mocked.constructed().get(0)).setVisible(true);
        }
    }


  
}
