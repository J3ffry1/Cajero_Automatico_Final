package com.mycompany.cajeroautomatico;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

import Modelo.ServicioUsuario;
import Vista.MenuOperaciones;
import Vista.MenuOperaciones2;
import Vista.MenuOperaciones3;
import controlador.MenuControlador;
import controlador.PersonalVenContro;
import persistencia.ServicioTrans;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.MockedConstruction; // Importar MockedConstruction

public class PersonalVenControTest {

    @Mock
    private ServicioUsuario servicioUsuario;
    @Mock
    private ServicioTrans servicioTrans;

    private PersonalVenContro personalVenContro;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
        personalVenContro = new PersonalVenContro(servicioUsuario, servicioTrans);
    }

    @Test
    public void testAbrirMenuOperacionesCajero1() {
        String usuario = "testUser1";
        int cajero = 1;

        // Usamos MockedConstruction para interceptar la creación de MenuOperaciones
        try (MockedConstruction<MenuOperaciones> mockedMenuOperaciones = mockConstruction(MenuOperaciones.class)) {
            personalVenContro.abrirMenuOperaciones(usuario, cajero);

            // Verificamos que se creó una instancia de MenuOperaciones
            assertEquals(1, mockedMenuOperaciones.constructed().size(), "Debe crearse una instancia de MenuOperaciones");
            MenuOperaciones menuOperaciones = mockedMenuOperaciones.constructed().get(0);

            // Verificamos que se llamó a setVisible(true) en la instancia creada
            verify(menuOperaciones).setVisible(true);

            // Opcional: Verificar los argumentos del constructor si es necesario
            // ArgumentCaptor<MenuControlador> captor = ArgumentCaptor.forClass(MenuControlador.class);
            // verify(menuOperaciones).<init>(eq(usuario), captor.capture());
            // MenuControlador capturedController = captor.getValue();
            // assertNotNull(capturedController);
        }
    }

    @Test
    public void testAbrirMenuOperacionesCajero2() {
        String usuario = "testUser2";
        int cajero = 2;

        // Usamos MockedConstruction para interceptar la creación de MenuOperaciones2
        try (MockedConstruction<MenuOperaciones2> mockedMenuOperaciones2 = mockConstruction(MenuOperaciones2.class)) {
            personalVenContro.abrirMenuOperaciones(usuario, cajero);

            // Verificamos que se creó una instancia de MenuOperaciones2
            assertEquals(1, mockedMenuOperaciones2.constructed().size(), "Debe crearse una instancia de MenuOperaciones2");
            MenuOperaciones2 menuOperaciones2 = mockedMenuOperaciones2.constructed().get(0);

            // Verificamos que se llamó a setVisible(true) en la instancia creada
            verify(menuOperaciones2).setVisible(true);
        }
    }

    @Test
    public void testAbrirMenuOperacionesCajero3() {
        String usuario = "testUser3";
        int cajero = 3;

        // Usamos MockedConstruction para interceptar la creación de MenuOperaciones3
        try (MockedConstruction<MenuOperaciones3> mockedMenuOperaciones3 = mockConstruction(MenuOperaciones3.class)) {
            personalVenContro.abrirMenuOperaciones(usuario, cajero);

            // Verificamos que se creó una instancia de MenuOperaciones3
            assertEquals(1, mockedMenuOperaciones3.constructed().size(), "Debe crearse una instancia de MenuOperaciones3");
            MenuOperaciones3 menuOperaciones3 = mockedMenuOperaciones3.constructed().get(0);

            // Verificamos que se llamó a setVisible(true) en la instancia creada
            verify(menuOperaciones3).setVisible(true);
        }
    }

    @Test
    public void testAbrirMenuOperacionesCajeroInvalido() {
        // Arrange
        String usuario = "usuarioInvalido";
        
        // Act & Assert
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            personalVenContro.abrirMenuOperaciones(usuario, 4); // Cajero no válido
        });
        
        // Assert
        assertEquals("Cajero no válido", exception.getMessage());
    }
}
