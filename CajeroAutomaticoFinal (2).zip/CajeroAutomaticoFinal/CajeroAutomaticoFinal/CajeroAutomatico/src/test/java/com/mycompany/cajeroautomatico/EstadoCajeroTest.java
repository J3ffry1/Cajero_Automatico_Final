package com.mycompany.cajeroautomatico;

import Modelo.ServicioUsuario;
import state.CajeroContexto;
import state.EstadoCajero;
import state.EstadoMenuPrincipal;
import state.EstadoMantenimiento;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
import persistencia.ServicioTrans;

public class EstadoCajeroTest {

    private CajeroContexto contexto;

    @BeforeEach
    void setUp() {
        contexto = new CajeroContexto(mock(ServicioUsuario.class), mock(ServicioTrans.class));
    }

    @Test
    void testEstadoMenuPrincipalEjecutar() {
        EstadoCajero estadoMenuPrincipal = new EstadoMenuPrincipal(contexto);

        // Verificamos que no lanza excepciones al ejecutar
        assertDoesNotThrow(() -> estadoMenuPrincipal.ejecutar());
    }

    @Test
    void testEstadoMantenimientoEjecutar() {
        EstadoCajero estadoMantenimiento = new EstadoMantenimiento(contexto);

        // Verificamos que no lanza excepciones al ejecutar
        assertDoesNotThrow(() -> estadoMantenimiento.ejecutar());
    }

    @Test
    void testCajeroContextoEjecutarConEstado() {
        EstadoCajero estadoMenuPrincipal = new EstadoMenuPrincipal(contexto);
        contexto.setEstado(estadoMenuPrincipal);

        // Verificamos que se llama al método ejecutar del estado
        assertDoesNotThrow(() -> contexto.ejecutar());
    }

    @Test
    void testCajeroContextoEjecutarSinEstado() {
        contexto.setEstado(null);
        // Verificamos que no lanza excepciones
        assertDoesNotThrow(() -> contexto.ejecutar());
    }

    @Test
    void testSetEstado() {
        EstadoCajero estadoMenuPrincipal = new EstadoMenuPrincipal(contexto);
        contexto.setEstado(estadoMenuPrincipal);
        assertNotNull(contexto);
    }
}
