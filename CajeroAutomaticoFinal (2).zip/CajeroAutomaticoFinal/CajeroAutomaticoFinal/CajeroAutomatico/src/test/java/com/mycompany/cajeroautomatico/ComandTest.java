package com.mycompany.cajeroautomatico;

import Modelo.ServicioUsuario;
import command.Command;
import command.CommandHistory;
import command.DepositoCommand;
import command.RetiroCommand;
import command.TransferenciaCommand;
import persistencia.ServicioTrans;
import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class CommandTest {

    // Tests para DepositoCommand
    @Test
    void testDepositoCommandExecute() {
        ServicioUsuario usuarioMock = mock(ServicioUsuario.class);
        ServicioTrans transMock = mock(ServicioTrans.class);
        DepositoCommand cmd = new DepositoCommand(usuarioMock, transMock, "user1", 100.0);
        
        cmd.execute();
        
        verify(usuarioMock).actualizarSaldo("user1", 100.0);
        verify(transMock).registrarTransaccion("user1", "DEPOSITO", 100.0);
    }

    @Test
    void testDepositoCommandUndo() {
        ServicioUsuario usuarioMock = mock(ServicioUsuario.class);
        ServicioTrans transMock = mock(ServicioTrans.class);
        DepositoCommand cmd = new DepositoCommand(usuarioMock, transMock, "user1", 100.0);
        
        cmd.undo();
        
        verify(usuarioMock).actualizarSaldo("user1", -100.0);
        verify(transMock).registrarTransaccion("user1", "DESHACER DEPOSITO", -100.0);
    }

    // Tests para RetiroCommand
    @Test
    void testRetiroCommandExecute() {
        ServicioUsuario usuarioMock = mock(ServicioUsuario.class);
        ServicioTrans transMock = mock(ServicioTrans.class);
        RetiroCommand cmd = new RetiroCommand(usuarioMock, transMock, "user1", 50.0);
        
        cmd.execute();
        
        verify(usuarioMock).actualizarSaldo("user1", -50.0);
        verify(transMock).registrarTransaccion("user1", "RETIRO", 50.0);
    }

    @Test
    void testRetiroCommandUndo() {
        ServicioUsuario usuarioMock = mock(ServicioUsuario.class);
        ServicioTrans transMock = mock(ServicioTrans.class);
        RetiroCommand cmd = new RetiroCommand(usuarioMock, transMock, "user1", 50.0);
        
        cmd.undo();
        
        verify(usuarioMock).actualizarSaldo("user1", 50.0);
        verify(transMock).registrarTransaccion("user1", "DESHACER RETIRO", 50.0);
    }

    // Tests para TransferenciaCommand
    @Test
    void testTransferenciaCommandExecute() {
        ServicioUsuario usuarioMock = mock(ServicioUsuario.class);
        ServicioTrans transMock = mock(ServicioTrans.class);
        TransferenciaCommand cmd = new TransferenciaCommand(usuarioMock, transMock, "user1", "user2", 200.0);
        
        cmd.execute();
        
        verify(usuarioMock).actualizarSaldo("user1", -210.0); // 200 + 5% comisión
        verify(usuarioMock).actualizarSaldo("user2", 200.0);
        verify(transMock).registrarTransaccion("user1", "TRANSFERENCIA_INTERNACIONAL", 210.0);
    }

    @Test
    void testTransferenciaCommandUndo() {
        ServicioUsuario usuarioMock = mock(ServicioUsuario.class);
        ServicioTrans transMock = mock(ServicioTrans.class);
        TransferenciaCommand cmd = new TransferenciaCommand(usuarioMock, transMock, "user1", "user2", 200.0);
        
        cmd.undo();
        
        verify(usuarioMock).actualizarSaldo("user1", 210.0);
        verify(usuarioMock).actualizarSaldo("user2", -200.0);
        verify(transMock).registrarTransaccion("user1", "DESHACER TRANSFERENCIA", -210.0);
    }

    // Tests para CommandHistory
    @Test
    void testCommandHistoryPushAndUndo() {
        CommandHistory history = new CommandHistory();
        Command mockCommand = mock(Command.class);
        
        history.push(mockCommand);
        assertTrue(history.canUndo());
        
        history.undo();
        verify(mockCommand).undo();
        assertTrue(history.canRedo());
    }

    @Test
    void testCommandHistoryRedo() {
        CommandHistory history = new CommandHistory();
        Command mockCommand = mock(Command.class);
        
        history.push(mockCommand);
        history.undo();
        history.redo();
        
        verify(mockCommand).execute();
        assertTrue(history.canUndo());
    }

    @Test
    void testCommandHistoryEmptyStates() {
        CommandHistory history = new CommandHistory();
        
        assertFalse(history.canUndo());
        assertFalse(history.canRedo());
    }
}