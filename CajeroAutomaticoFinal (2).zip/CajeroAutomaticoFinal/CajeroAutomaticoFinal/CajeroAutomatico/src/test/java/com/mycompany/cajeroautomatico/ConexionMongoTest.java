/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cajeroautomatico;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;
import persistencia.ConexionMongo;
import Modelo.Usuario;

public class ConexionMongoTest {

    private static ConexionMongo conexion;

    @BeforeAll
    static void setup() {
        conexion = new ConexionMongo();
    }

    @Test
    @DisplayName("Test guardar y autenticar usuario")
    void testGuardarYAutenticar() {
        Usuario usuario = new Usuario();
        usuario.setUsuario("testUser");
        usuario.setContrasena("pass123");
        usuario.setSaldo(1000.0);
        usuario.setNombreCompleto("Juan");
        usuario.setApellidos("Perez");
        usuario.setFechaNacimiento("1990-01-01");
        usuario.setPais("Ecuador");
        usuario.setTelefono("0999999999");
        usuario.setCorreo("juan@example.com");

        conexion.guardarUsuario(usuario);

        assertTrue(conexion.autenticarUsuario("testUser", "pass123"),
                   "Debe autenticar usuario recién creado");

        assertFalse(conexion.autenticarUsuario("testUser", "wrongpass"),
                    "No debe autenticar con contraseña errónea");
    }

    @Test
    @DisplayName("Test obtener y actualizar saldo")
    void testSaldo() {
        double saldoInicial = conexion.obtenerSaldo("testUser");
        conexion.actualizarSaldo("testUser", 500.0);
        double saldoActualizado = conexion.obtenerSaldo("testUser");

        assertEquals(saldoInicial + 500.0, saldoActualizado, 0.01);
    }

    @Test
    @DisplayName("Test obtener nombre completo")
    void testObtenerNombre() {
        String nombre = conexion.obtenerNombreCuenta("testUser");
        assertEquals("Juan Perez", nombre, "Debe devolver nombre y apellidos concatenados");
    }
}
