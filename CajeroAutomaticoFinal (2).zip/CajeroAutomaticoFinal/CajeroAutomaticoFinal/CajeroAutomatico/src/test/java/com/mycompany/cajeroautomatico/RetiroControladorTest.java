package com.mycompany.cajeroautomatico;

import Modelo.ResultadoOperacion;
import Modelo.ServicioUsuario;
import controlador.RetiroControlador;
import controlador.estrategias.OperacionBancaria;
import persistencia.ServicioTrans;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class RetiroControladorTest {

    @Mock
    private ServicioUsuario servicioUsuarioMock;
    
    @Mock
    private ServicioTrans servicioTransMock;
    
    @Mock
    private OperacionBancaria estrategiaMock;
    
    private RetiroControlador retiroControlador;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        retiroControlador = new RetiroControlador(servicioUsuarioMock, servicioTransMock, estrategiaMock);
    }


    @Test
    void realizarRetiro_DelegaAEstrategiaYRetornaResultado() {
        // Configurar el mock
        String usuario = "user1";
        double monto = 500.0;
        ResultadoOperacion resultadoEsperado = new ResultadoOperacion(true, "Retiro exitoso");
        
        when(estrategiaMock.ejecutar(usuario, monto)).thenReturn(resultadoEsperado);
        
        // Ejecutar
        ResultadoOperacion resultado = retiroControlador.realizarRetiro(usuario, monto);
        
        // Verificar
        assertAll(
            () -> assertEquals(resultadoEsperado.isExito(), resultado.isExito()),
            () -> assertEquals(resultadoEsperado.getMensaje(), resultado.getMensaje())
        );
        verify(estrategiaMock).ejecutar(usuario, monto);
    }

    @Test
    void realizarRetiro_ConError_RetornaResultadoFallido() {
        String usuario = "user1";
        double monto = 500.0;
        ResultadoOperacion resultadoEsperado = new ResultadoOperacion(false, "Error en retiro");
        
        when(estrategiaMock.ejecutar(usuario, monto)).thenReturn(resultadoEsperado);
        
        ResultadoOperacion resultado = retiroControlador.realizarRetiro(usuario, monto);
        
        assertAll(
            () -> assertFalse(resultado.isExito()),
            () -> assertEquals("Error en retiro", resultado.getMensaje())
        );
    }

    @Test
    void puedeDeshacer_DelegaAEstrategia() {
        when(estrategiaMock.puedeDeshacer()).thenReturn(true);
        assertTrue(retiroControlador.puedeDeshacer());
        verify(estrategiaMock).puedeDeshacer();
    }

    @Test
    void puedeRehacer_DelegaAEstrategia() {
        when(estrategiaMock.puedeRehacer()).thenReturn(true);
        assertTrue(retiroControlador.puedeRehacer());
        verify(estrategiaMock).puedeRehacer();
    }

    @Test
    void deshacer_DelegaAEstrategia() {
        retiroControlador.deshacer();
        verify(estrategiaMock).deshacer();
    }

    @Test
    void rehacer_DelegaAEstrategia() {
        retiroControlador.rehacer();
        verify(estrategiaMock).rehacer();
    }

    @Test
    void constructorDefault_CreaInstanciaCorrectamente() {
        RetiroControlador controlador = new RetiroControlador(servicioUsuarioMock, servicioTransMock);
        assertNotNull(controlador);
    }
}