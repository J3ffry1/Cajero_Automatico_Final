/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cajeroautomatico;

import controlador.InicioControlador;
import Modelo.ServicioUsuario;
import persistencia.ServicioTrans;
import Vista.Inicio;
import Vista.Principal;
import controlador.MenuControlador;
import controlador.PrincipalControlador;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.MockedConstruction;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class InicioControladorTest {

    @Mock
    private ServicioUsuario servicioUsuarioMock;
    @Mock
    private ServicioTrans servicioTransMock;

    private InicioControlador inicioControlador;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        inicioControlador = new InicioControlador(servicioUsuarioMock, servicioTransMock);
    }

    @Test
    void testConstructor_serviciosNulos_lanzaExcepcion() {
        assertThrows(IllegalArgumentException.class, () -> new InicioControlador(null, servicioTransMock));
        assertThrows(IllegalArgumentException.class, () -> new InicioControlador(servicioUsuarioMock, null));
    }

    @Test
    void testAutenticarUsuario_credencialesValidas() {
        String usuario = "user";
        String contrasena = "pass";
        when(servicioUsuarioMock.autenticarUsuario(usuario, contrasena)).thenReturn(true);

        boolean resultado = inicioControlador.autenticarUsuario(usuario, contrasena);
        assertTrue(resultado);
        verify(servicioUsuarioMock).autenticarUsuario(usuario, contrasena);
    }

    @Test
    void testAutenticarUsuario_credencialesInvalidas() {
        String usuario = "user";
        String contrasena = "wrongpass";
        when(servicioUsuarioMock.autenticarUsuario(usuario, contrasena)).thenReturn(false);

        boolean resultado = inicioControlador.autenticarUsuario(usuario, contrasena);
        assertFalse(resultado);
        verify(servicioUsuarioMock).autenticarUsuario(usuario, contrasena);
    }

    @Test
    void testAutenticarUsuario_usuarioNulo_lanzaExcepcion() {
        assertThrows(IllegalArgumentException.class, () -> inicioControlador.autenticarUsuario(null, "pass"));
    }

    @Test
    void testAutenticarUsuario_usuarioVacio_lanzaExcepcion() {
        assertThrows(IllegalArgumentException.class, () -> inicioControlador.autenticarUsuario("   ", "pass"));
    }

    @Test
    void testAutenticarUsuario_contrasenaNula_lanzaExcepcion() {
        assertThrows(IllegalArgumentException.class, () -> inicioControlador.autenticarUsuario("user", null));
    }

    @Test
    void testAutenticarUsuario_contrasenaVacia_lanzaExcepcion() {
        assertThrows(IllegalArgumentException.class, () -> inicioControlador.autenticarUsuario("user", "   "));
    }

    @Test
    void testMostrarVentanaInicio_vistaNula_creaYMuestra() {
        // Asegurarse de que vistaInicio es nula al inicio del test
        inicioControlador.setVistaInicio(null);

        try (MockedConstruction<Inicio> mockedInicio = mockConstruction(Inicio.class)) {
            inicioControlador.mostrarVentanaInicio();
            // Verifica que se construyó una nueva instancia de Inicio
            verify(mockedInicio.constructed().get(0)).setVisible(true);
        }
    }

@Test
void testMostrarVentanaInicio_vistaExistente_soloMuestra() {
    Inicio vistaExistente = mock(Inicio.class);
    inicioControlador.setVistaInicio(vistaExistente);

    inicioControlador.mostrarVentanaInicio();

    // Verifica que se llamó a setVisible en la vista existente
    verify(vistaExistente).setVisible(true);
    // Asegúrate de que no se construyó una nueva instancia
    verifyNoMoreInteractions(vistaExistente);
}



    @Test
    public void testInicioSesionExitoso() {
        String usuario = "testUser ";

        // Usamos MockedConstruction para interceptar la creación de Principal
        try (MockedConstruction<Principal> mockedPrincipal = mockConstruction(Principal.class)) {
            inicioControlador.inicioSesionExitoso(usuario);

            // Verificamos que se creó una instancia de Principal
            assertEquals(1, mockedPrincipal.constructed().size(), "Debe crearse una instancia de Principal");
            Principal principalView = mockedPrincipal.constructed().get(0);

            // Verificamos que se llamó a setVisible(true) en la instancia creada
            verify(principalView).setVisible(true);
        }
    }

   
}

 
    
