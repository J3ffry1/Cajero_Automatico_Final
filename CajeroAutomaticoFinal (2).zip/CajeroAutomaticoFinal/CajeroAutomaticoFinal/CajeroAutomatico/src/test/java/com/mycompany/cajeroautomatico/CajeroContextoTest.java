/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cajeroautomatico;


import Modelo.ServicioUsuario;
import persistencia.ServicioTrans;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;
import state.CajeroContexto;
import state.EstadoCajero;

class CajeroContextoTest {
    private CajeroContexto contexto;
    private ServicioUsuario servicioUsuarioMock;
    private ServicioTrans servicioTransMock;
    private EstadoCajero estadoMock;

    @BeforeEach
    void setUp() {
        servicioUsuarioMock = mock(ServicioUsuario.class);
        servicioTransMock = mock(ServicioTrans.class);
        contexto = new CajeroContexto(servicioUsuarioMock, servicioTransMock);
        estadoMock = mock(EstadoCajero.class);
    }

    @Test
    void testSetEstado() {
        contexto.setEstado(estadoMock);
        // Verificamos que no hubo excepciones
        assertDoesNotThrow(() -> contexto.ejecutar());
    }

    @Test
    void testEjecutarConEstado() {
        contexto.setEstado(estadoMock);
        contexto.ejecutar();
        // Verificamos que se llamó al método ejecutar del estado
        verify(estadoMock).ejecutar();
    }

    @Test
    void testEjecutarSinEstado() {
        contexto.setEstado(null);
        // Verificamos que no lanza excepciones
        assertDoesNotThrow(() -> contexto.ejecutar());
    }
}