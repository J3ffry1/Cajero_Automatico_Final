package com.mycompany.cajeroautomatico;

import command.Command;
import command.CommandHistory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class NewClass {
    private CommandHistory commandHistory;
    private Command mockCommand;

    @BeforeEach
    void setUp() {
        commandHistory = new CommandHistory();
        mockCommand = mock(Command.class);
    }

    @Test
    void testPushAndCanUndo() {
        assertFalse(commandHistory.canUndo());
        commandHistory.push(mockCommand);
        assertTrue(commandHistory.canUndo());
    }

    @Test
    void testUndo() {
        commandHistory.push(mockCommand);
        commandHistory.undo();
        verify(mockCommand).undo();
        assertTrue(commandHistory.canRedo());
    }

    @Test
    void testRedo() {
        commandHistory.push(mockCommand);
        commandHistory.undo();
        commandHistory.redo();
        verify(mockCommand).execute();
    }
}