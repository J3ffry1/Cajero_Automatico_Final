package com.mycompany.cajeroautomatico;

import controlador.AutenticarControlador;
import controlador.DepositoControlador;
import controlador.RetiroControlador;
import controlador.TransIContro;
import Modelo.ResultadoOperacion;
import Modelo.ServicioUsuario;
import controlador.estrategias.EstrategiaDeposito;
import controlador.estrategias.EstrategiaRetiro;
import persistencia.ServicioTrans;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ControladorTest2 {

    @Mock
    private ServicioUsuario servicioUsuarioMock;

    @Mock
    private ServicioTrans servicioTransMock;

    private AutenticarControlador autenticarControlador;
    private DepositoControlador depositoControlador;
    private RetiroControlador retiroControlador;
    private TransIContro transIContro;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        autenticarControlador = new AutenticarControlador(servicioUsuarioMock);
        depositoControlador = new DepositoControlador(servicioUsuarioMock, servicioTransMock, new EstrategiaDeposito(servicioUsuarioMock, servicioTransMock));
        retiroControlador = new RetiroControlador(servicioUsuarioMock, servicioTransMock, new EstrategiaRetiro(servicioUsuarioMock, servicioTransMock));
        transIContro = new TransIContro(servicioUsuarioMock, servicioTransMock);
    }

    // Tests para AutenticarControlador
    @Test
    void testAutenticarUsuario_Exito() {
        // Arrange
        String usuario = "testUser ";
        String contrasena = "testPass";
        when(servicioUsuarioMock.autenticarUsuario(usuario, contrasena)).thenReturn(true);

        // Act
        boolean resultado = autenticarControlador.autenticar(usuario, contrasena);

        // Assert
        assertTrue(resultado);
        verify(servicioUsuarioMock).autenticarUsuario(usuario, contrasena);
    }

    @Test
    void testAutenticarUsuario_Fallo() {
        // Arrange
        String usuario = "testUser ";
        String contrasena = "wrongPass";
        when(servicioUsuarioMock.autenticarUsuario(usuario, contrasena)).thenReturn(false);

        // Act
        boolean resultado = autenticarControlador.autenticar(usuario, contrasena);

        // Assert
        assertFalse(resultado);
        verify(servicioUsuarioMock).autenticarUsuario(usuario, contrasena);
    }

    // Tests para DepositoControlador
    @Test
    void testRealizarDeposito_Exito() {
        // Arrange
        String usuario = "testUser ";
        double monto = 100.0;
        ResultadoOperacion resultadoEsperado = new ResultadoOperacion(true, "Depósito exitoso");
        when(depositoControlador.realizarDeposito(usuario, monto)).thenReturn(resultadoEsperado);

        // Act
        ResultadoOperacion resultadoActual = depositoControlador.realizarDeposito(usuario, monto);

        // Assert
        assertEquals(resultadoEsperado, resultadoActual);
        verify(depositoControlador).realizarDeposito(usuario, monto);
    }

    @Test
    void testRealizarDeposito_Fallo() {
        // Arrange
        String usuario = "testUser ";
        double monto = -50.0; // Monto inválido
        ResultadoOperacion resultadoEsperado = new ResultadoOperacion(false, "El monto debe ser mayor a cero");
        when(depositoControlador.realizarDeposito(usuario, monto)).thenReturn(resultadoEsperado);

        // Act
        ResultadoOperacion resultadoActual = depositoControlador.realizarDeposito(usuario, monto);

        // Assert
        assertEquals(resultadoEsperado, resultadoActual);
        verify(depositoControlador).realizarDeposito(usuario, monto);
    }

    // Tests para RetiroControlador
    @Test
    void testRealizarRetiro_Exito() {
        // Arrange
        String usuario = "testUser ";
        double monto = 50.0;
        ResultadoOperacion resultadoEsperado = new ResultadoOperacion(true, "Retiro exitoso");
        when(retiroControlador.realizarRetiro(usuario, monto)).thenReturn(resultadoEsperado);

        // Act
        ResultadoOperacion resultadoActual = retiroControlador.realizarRetiro(usuario, monto);

        // Assert
        assertEquals(resultadoEsperado, resultadoActual);
        verify(retiroControlador).realizarRetiro(usuario, monto);
    }

    @Test
    void testRealizarRetiro_SaldoInsuficiente() {
        // Arrange
        String usuario = "testUser ";
        double monto = 150.0; // Monto mayor que el saldo
        ResultadoOperacion resultadoEsperado = new ResultadoOperacion(false, "Saldo insuficiente");
        when(retiroControlador.realizarRetiro(usuario, monto)).thenReturn(resultadoEsperado);

        // Act
        ResultadoOperacion resultadoActual = retiroControlador.realizarRetiro(usuario, monto);

        // Assert
        assertEquals(resultadoEsperado, resultadoActual);
        verify(retiroControlador).realizarRetiro(usuario, monto);
    }

    // Tests para TransIContro
    @Test
    void testRealizarTransferencia_Exito() {
        // Arrange
        String usuarioOrigen = "user1";
        String cuentaDestino = "user2";
        double monto = 100.0;
        ResultadoOperacion resultadoEsperado = new ResultadoOperacion(true, "Transferencia exitosa");
        when(transIContro.realizarTransferencia(usuarioOrigen, cuentaDestino, monto)).thenReturn(resultadoEsperado);

        // Act
        ResultadoOperacion resultadoActual = transIContro.realizarTransferencia(usuarioOrigen, cuentaDestino, monto);

        // Assert
        assertEquals(resultadoEsperado, resultadoActual);
        verify(transIContro).realizarTransferencia(usuarioOrigen, cuentaDestino, monto);
    }

    @Test
    void testRealizarTransferencia_CuentaDestinoNoExistente() {
        // Arrange
        String usuarioOrigen = "user1";
        String cuentaDestino = "nonExistentUser ";
        double monto = 100.0;
        ResultadoOperacion resultadoEsperado = new ResultadoOperacion(false, "La cuenta destino no existe");
        when(transIContro.realizarTransferencia(usuarioOrigen, cuentaDestino, monto)).thenReturn(resultadoEsperado);

        // Act
        ResultadoOperacion resultadoActual = transIContro.realizarTransferencia(usuarioOrigen, cuentaDestino, monto);

        // Assert
        assertEquals(resultadoEsperado, resultadoActual);
        verify(transIContro).realizarTransferencia(usuarioOrigen, cuentaDestino, monto);
    }
}
