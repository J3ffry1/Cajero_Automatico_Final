/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cajeroautomatico;


import Vista.CajeroOpcion;
import controlador.MenuControlador;
import Modelo.ServicioUsuario;
import persistencia.ServicioTrans;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.mockito.Mockito.*;

public class CajeroOpcionTest {

    private CajeroOpcion cajeroOpcion;
    private ServicioUsuario mockServicioUsuario;
    private ServicioTrans mockServicioTrans;
    private MenuControlador controlador;

    @BeforeEach
    public void setUp() {
        // Crear mocks
        mockServicioUsuario = mock(ServicioUsuario.class);
        mockServicioTrans = mock(ServicioTrans.class);

        // Crear el controlador con los mocks
        controlador = new MenuControlador(mockServicioUsuario, mockServicioTrans);

        // Crear la vista que se va a probar
        cajeroOpcion = new CajeroOpcion(controlador, "usuarioPrueba");
    }

    @Test
    public void testConsultaSaldoAction() {
        cajeroOpcion.getBtnConsulta().doClick();
        // Aquí podrías verificar interacciones si quisieras
        // verify(mockServicioUsuario).obtenerSaldo("usuarioPrueba");
    }

    @Test
    public void testRetiroAction() {
        cajeroOpcion.getBtnRetiro().doClick();
        // Aquí podrías usar verify(...) si hay algo que esperas
    }

    @Test
    public void testSalirAction() {
        cajeroOpcion.getBtnSalir().doClick();
        // Aquí podrías verificar si la ventana se ocultó, etc.
    }
}
