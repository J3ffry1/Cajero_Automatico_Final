package com.mycompany.cajeroautomatico;

import controlador.TransIContro;
import Modelo.ServicioUsuario;
import persistencia.ServicioTrans;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class TransIControTest {

    @Mock
    private ServicioUsuario servicioUsuarioMock;
    @Mock
    private ServicioTrans servicioTransMock;

    private TransIContro transIContro;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        transIContro = new TransIContro(servicioUsuarioMock, servicioTransMock);
    }

    @Test
    void testConstructor_serviciosNulos_lanzaExcepcion() {
        assertThrows(IllegalArgumentException.class, () -> new TransIContro(null, servicioTransMock));
        assertThrows(IllegalArgumentException.class, () -> new TransIContro(servicioUsuarioMock, null));
    }

    @Test
    void testRealizarTransferencia_delegaAEstrategia() {
        String usuarioOrigen = "user1";
        String cuentaDestino = "user2";
        double monto = 100.0;
        
        transIContro.realizarTransferencia(usuarioOrigen, cuentaDestino, monto);
        
        // Verificamos que se creó y usó la estrategia interna
        verify(servicioUsuarioMock, atLeastOnce()).verificarCuentaExistente(anyString());
    }

    @Test
    void testPuedeDeshacer_delegaAEstrategia() {
        transIContro.puedeDeshacer();
        // Verificación implícita de que no lanza excepciones
        // La lógica real estaría en la estrategia
    }

    @Test
    void testPuedeRehacer_delegaAEstrategia() {
        transIContro.puedeRehacer();
        // Verificación implícita de que no lanza excepciones
    }

    @Test
    void testDeshacer_delegaAEstrategia() {
        transIContro.deshacer();
        // Verificación implícita de que no lanza excepciones
    }

    @Test
    void testRehacer_delegaAEstrategia() {
        transIContro.rehacer();
        // Verificación implícita de que no lanza excepciones
    }
}