package com.mycompany.cajeroautomatico;

import Vista.Registrar;
import static org.mockito.Mockito.*;

import java.awt.event.ActionEvent;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockedStatic;
import org.mockito.junit.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class RegistrarTest {
    
    private Registrar registrar;
    private MockedStatic<JOptionPane> mockedJOptionPane; // referencia al mock estático
    
    @Mock private JTextField mockNom;
    @Mock private JTextField mockApellido;
    @Mock private JTextField mockFecha;
    @Mock private JTextField mockPais;
    @Mock private JTextField mockCorre;
    @Mock private JTextField mockTele;
    @Mock private JTextField mockUsu;
    @Mock private JTextField mockContra;
    @Mock private JTextField mockSaldo;
    
    @Before
    public void setUp() throws Exception {
        registrar = new Registrar();
        
        // Inyectar mocks usando Reflection
        setPrivateField(registrar, "nom", mockNom);
        setPrivateField(registrar, "apellido", mockApellido);
        setPrivateField(registrar, "fecha", mockFecha);
        setPrivateField(registrar, "pais", mockPais);
        setPrivateField(registrar, "corre", mockCorre);
        setPrivateField(registrar, "tele", mockTele);
        setPrivateField(registrar, "usu", mockUsu);
        setPrivateField(registrar, "contra", mockContra);
        setPrivateField(registrar, "saldo", mockSaldo);
        
        // Mockear JOptionPane y guardarlo
        mockedJOptionPane = mockStatic(JOptionPane.class);
        mockedJOptionPane.when(() -> JOptionPane.showMessageDialog(any(), anyString()))
                         .thenAnswer(invocation -> null);
    }
    
    @After
    public void tearDown() {
        // Cerrar el mock estático para evitar conflictos en otros tests
        mockedJOptionPane.close();
    }
    
    private void setPrivateField(Object target, String fieldName, Object value) throws Exception {
        Field field = target.getClass().getDeclaredField(fieldName);
        field.setAccessible(true);
        field.set(target, value);
    }
    
    private void simulateTextFieldInput(JTextField mockField, String value) {
        when(mockField.getText()).thenReturn(value);
        when(mockField.getText().trim()).thenReturn(value.trim());
    }
    
   
    

    
    @Test
    public void testLimpiarCampos() throws Exception {
        Method method = registrar.getClass().getDeclaredMethod("limpiarCampos");
        method.setAccessible(true);
        method.invoke(registrar);
        
        verify(mockNom).setText("");
        verify(mockApellido).setText("");
        verify(mockFecha).setText("");
        verify(mockPais).setText("");
        verify(mockCorre).setText("");
        verify(mockTele).setText("");
        verify(mockUsu).setText("");
        verify(mockContra).setText("");
        verify(mockSaldo).setText("");
    }
}
