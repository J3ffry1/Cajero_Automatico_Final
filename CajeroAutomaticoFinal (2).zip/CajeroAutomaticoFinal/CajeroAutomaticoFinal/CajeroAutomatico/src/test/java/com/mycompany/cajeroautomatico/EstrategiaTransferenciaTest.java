 
package com.mycompany.cajeroautomatico;

import Modelo.ResultadoOperacion;
import Modelo.ServicioUsuario;
import command.CommandHistory;
import command.TransferenciaCommand;
import controlador.estrategias.EstrategiaTransferencia;
import persistencia.ServicioTrans;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

 class EstrategiaTransferenciaTest {

    @Mock
    private ServicioUsuario servicioUsuarioMock;
    
    @Mock
    private ServicioTrans servicioTransMock;
    
    @Mock
    private CommandHistory commandHistoryMock;
    
    private EstrategiaTransferencia estrategiaTransferencia;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        estrategiaTransferencia = new EstrategiaTransferencia(servicioUsuarioMock, servicioTransMock, commandHistoryMock);
    }

   

    @Test
    void ejecutar_Falla_CuentaDestinoNoExiste() {
        String usuarioOrigen = "user1";
        String usuarioDestino = "user99";
        double monto = 500.0;
        
        when(servicioUsuarioMock.verificarCuentaExistente(usuarioDestino)).thenReturn(false);
        
        ResultadoOperacion resultado = estrategiaTransferencia.ejecutar(usuarioOrigen, usuarioDestino, monto);
        
        assertAll(
            () -> assertFalse(resultado.isExito()),
            () -> assertTrue(resultado.getMensaje().contains("no existe")),
            () -> verify(servicioUsuarioMock, never()).obtenerSaldo(anyString())
        );
    }

    @Test
    void ejecutar_Falla_SaldoInsuficiente() {
        String usuarioOrigen = "user1";
        String usuarioDestino = "user2";
        double monto = 500.0;
        double saldoInsuficiente = 300.0;
        
        when(servicioUsuarioMock.verificarCuentaExistente(usuarioDestino)).thenReturn(true);
        when(servicioUsuarioMock.obtenerSaldo(usuarioOrigen)).thenReturn(saldoInsuficiente);
        
        ResultadoOperacion resultado = estrategiaTransferencia.ejecutar(usuarioOrigen, usuarioDestino, monto);
        
        assertAll(
            () -> assertFalse(resultado.isExito()),
            () -> assertTrue(resultado.getMensaje().contains("Saldo insuficiente"))
        );
    }

    @Test
    void puedeDeshacer_RetornaTrue_CuandoHayComandos() {
        when(commandHistoryMock.canUndo()).thenReturn(true);
        assertTrue(estrategiaTransferencia.puedeDeshacer());
    }

    @Test
    void puedeRehacer_RetornaTrue_CuandoHayComandos() {
        when(commandHistoryMock.canRedo()).thenReturn(true);
        assertTrue(estrategiaTransferencia.puedeRehacer());
    }

    @Test
    void deshacer_EjecutaUndoEnCommandHistory() {
        estrategiaTransferencia.deshacer();
        verify(commandHistoryMock).undo();
    }

    @Test
    void rehacer_EjecutaRedoEnCommandHistory() {
        estrategiaTransferencia.rehacer();
        verify(commandHistoryMock).redo();
    }
}