/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cajeroautomatico;



import Vista.Inicio;
import controlador.InicioControlador;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import javax.swing.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class InicioTest {

    private InicioControlador controladorMock;

    @BeforeEach
    void setUp() {
        controladorMock = mock(InicioControlador.class);
    }

    @Test
    void testConstructorControladorNulo() {
        Exception ex = assertThrows(IllegalArgumentException.class, () -> {
            new Inicio(null);
        });
        assertTrue(ex.getMessage().contains("controlador"));
    }

    @Test
    void testConstructorValido() {
        Inicio inicio = new Inicio(controladorMock);
        assertNotNull(inicio);
        assertEquals("Banco ESPE - Inicio de Sesión", inicio.getTitle());
    }

  
   
 
}
