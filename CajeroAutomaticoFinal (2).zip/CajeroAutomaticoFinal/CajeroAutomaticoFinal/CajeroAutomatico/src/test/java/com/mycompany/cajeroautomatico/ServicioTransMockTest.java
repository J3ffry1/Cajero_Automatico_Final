/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cajeroautomatico;


import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.mockito.Mockito.*;
import persistencia.ServicioTrans;

class ServicioTransMockTest {

    @Test
    void testRegistrarTransaccionConMock() {
        // Crear mock
        ServicioTrans mockServicio = Mockito.mock(ServicioTrans.class);

        // Simular llamada
        mockServicio.registrarTransaccion("usuarioMock", "DEPÓSITO", 200.0);

        // Verificar que se llamó al método con los argumentos correctos
        verify(mockServicio).registrarTransaccion("usuarioMock", "DEPÓSITO", 200.0);
    }

    @Test
    void testObtenerHistorialConMock() {
        ServicioTrans mockServicio = Mockito.mock(ServicioTrans.class);

        // Definir comportamiento simulado
        when(mockServicio.obtenerHistorial("usuarioMock"))
                .thenReturn("=== Historial de Transacciones ===\nusuarioMock DEPÓSITO 200.00");

        // Ejecutar y verificar
        String historial = mockServicio.obtenerHistorial("usuarioMock");
        assert(historial.contains("usuarioMock"));
        assert(historial.contains("DEPÓSITO"));
    }

    @Test
    void testValidarLimiteConMock() {
        ServicioTrans mockServicio = Mockito.mock(ServicioTrans.class);

        // Simular comportamiento del límite
        when(mockServicio.validarLimiteTransaccion(1000.0)).thenReturn(true);
        when(mockServicio.validarLimiteTransaccion(6000.0)).thenReturn(false);

        assert(mockServicio.validarLimiteTransaccion(1000.0));
        assert(!mockServicio.validarLimiteTransaccion(6000.0));
    }
}

