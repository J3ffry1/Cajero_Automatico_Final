package com.mycompany.cajeroautomatico;

import Modelo.ServicioUsuario;
import Modelo.Usuario;


import Vista.MenuPrincipal;
import persistencia.ServicioTrans;
import state.CajeroContexto;
import state.EstadoCajero;
import state.EstadoMantenimiento;
import state.EstadoMenuPrincipal;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import javax.swing.JOptionPane;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class CajeroStateTest {

    // Mocks comunes
    private ServicioUsuario servicioUsuarioMock;
    private ServicioTrans servicioTransMock;
    private CajeroContexto contextoMock;
    
    @BeforeEach
    void setUp() {
        servicioUsuarioMock = mock(ServicioUsuario.class);
        servicioTransMock = mock(ServicioTrans.class);
        contextoMock = mock(CajeroContexto.class);
    }

    /************************************
     * Pruebas para CajeroContexto
     ************************************/
    @Test
    void testCajeroContexto_SetEstado() {
        CajeroContexto contexto = new CajeroContexto(servicioUsuarioMock, servicioTransMock);
        EstadoCajero estadoMock = mock(EstadoCajero.class);
        
        contexto.setEstado(estadoMock);
        contexto.ejecutar();
        
        verify(estadoMock).ejecutar();
    }

    @Test
    void testCajeroContexto_EjecutarSinEstado() {
        CajeroContexto contexto = new CajeroContexto(servicioUsuarioMock, servicioTransMock);
        assertDoesNotThrow(() -> contexto.ejecutar());
    }

    /************************************
     * Pruebas para EstadoMantenimiento
     ************************************/

    /************************************
     * Pruebas para EstadoMenuPrincipal
     ************************************/
    @Test
    void testEstadoMenuPrincipal_Ejecutar() {
        EstadoMenuPrincipal estado = new EstadoMenuPrincipal(contextoMock);
        
        try (var mockedMenu = mockConstruction(MenuPrincipal.class)) {
            estado.ejecutar();
            
            assertEquals(1, mockedMenu.constructed().size());
            MenuPrincipal menu = mockedMenu.constructed().get(0);
            verify(menu).setVisible(true);
        }
    }

    /************************************
     * Pruebas para ServicioTransImpl
     ************************************/

}