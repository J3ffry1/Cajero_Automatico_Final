package com.mycompany.cajeroautomatico;

import controlador.MenuControlador;
import Modelo.ServicioUsuario;
import persistencia.ServicioTrans;
import Vista.CajeroOpcion;
import Vista.CajeroRetiro;
import Vista.DepositoFrame;
import Vista.TransferenciaInternacionalFrame;
import Vista.Inicio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import javax.swing.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class MenuControladorTest1 {

    @Mock
    private ServicioUsuario servicioUsuarioMock;

    @Mock
    private ServicioTrans servicioTransMock;

    private MenuControlador menuControlador;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        menuControlador = new MenuControlador(servicioUsuarioMock, servicioTransMock);
    }

    @Test
    void testConstructor_ServiciosNulos_LanzaIllegalArgumentException() {
        assertThrows(IllegalArgumentException.class, () -> 
            new MenuControlador(null, servicioTransMock));
        assertThrows(IllegalArgumentException.class, () -> 
            new MenuControlador(servicioUsuarioMock, null));
    }

    @Test
    void testObtenerSaldo() {
        String usuario = "testUser ";
        double saldoEsperado = 1000.0;

        when(servicioUsuarioMock.obtenerSaldo(usuario)).thenReturn(saldoEsperado);

        double saldoActual = menuControlador.obtenerSaldo(usuario);

        assertEquals(saldoEsperado, saldoActual);
        verify(servicioUsuarioMock).obtenerSaldo(usuario);
    }

    @Test
    void testObtenerHistorial() {
        String usuario = "testUser ";
        String historialEsperado = "Historial de transacciones";

        when(servicioTransMock.obtenerHistorial(usuario)).thenReturn(historialEsperado);

        String historialActual = menuControlador.obtenerHistorial(usuario);

        assertEquals(historialEsperado, historialActual);
        verify(servicioTransMock).obtenerHistorial(usuario);
    }

    @Test
    void testAbrirVentanaRetiro() {
        String usuario = "testUser ";

        // Act
        menuControlador.abrirVentanaRetiro(usuario);

        // Assert
        // Verificamos que se haya creado la ventana de retiro
        verify(servicioUsuarioMock).obtenerSaldo(usuario);
        verify(servicioTransMock).obtenerHistorial(usuario);
    }

    @Test
    void testAbrirVentanaDeposito() {
        String usuario = "testUser ";

        // Act
        menuControlador.abrirVentanaDeposito(usuario);

        // Assert
        // Verificamos que se haya creado la ventana de depósito
        verify(servicioUsuarioMock).obtenerSaldo(usuario);
        verify(servicioTransMock).obtenerHistorial(usuario);
    }

    @Test
    void testAbrirVentanaTransferencia() {
        String usuario = "testUser ";

        // Act
        menuControlador.abrirVentanaTransferencia(usuario);

        // Assert
        // Verificamos que se haya creado la ventana de transferencia
        verify(servicioUsuarioMock).obtenerSaldo(usuario);
        verify(servicioTransMock).obtenerHistorial(usuario);
    }

    @Test
    void testCerrarSesion() {
        // Act
        menuControlador.cerrarSesion();

        // Assert
        // Verificamos que se haya creado la ventana de inicio
        verify(servicioUsuarioMock).obtenerSaldo(anyString());
        verify(servicioTransMock).obtenerHistorial(anyString());
    }

    @Test
    void testCerrarSesionConVentanaActual() {
        JFrame ventanaActual = new JFrame();
        ventanaActual.setVisible(true);

        // Act
        menuControlador.cerrarSesion(ventanaActual);

        // Assert
        assertFalse(ventanaActual.isDisplayable()); // Verificamos que la ventana se haya cerrado
        verify(servicioUsuarioMock).obtenerSaldo(anyString());
        verify(servicioTransMock).obtenerHistorial(anyString());
    }

    @Test
    void testRegresarAMenu() {
        JFrame ventanaActual = new JFrame();
        ventanaActual.setVisible(true);
        String usuario = "testUser ";

        // Act
        menuControlador.regresarAMenu(ventanaActual, usuario);

        // Assert
        assertFalse(ventanaActual.isDisplayable()); // Verificamos que la ventana se haya cerrado
        verify(servicioUsuarioMock).obtenerSaldo(usuario);
        verify(servicioTransMock).obtenerHistorial(usuario);
    }
}
