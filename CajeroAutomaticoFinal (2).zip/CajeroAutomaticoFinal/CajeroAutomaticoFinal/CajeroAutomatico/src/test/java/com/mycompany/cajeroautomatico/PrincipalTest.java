/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cajeroautomatico;

import Vista.Principal;
import controlador.PrincipalControlador;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import javax.swing.*;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class PrincipalTest {

    private PrincipalControlador controladorMock;

    @BeforeEach
    void setUp() {
        controladorMock = mock(PrincipalControlador.class);
    }

    @Test
    void testConstructorConParametrosValidos() {
        Principal principal = new Principal("usuarioPrueba", controladorMock);
        assertNotNull(principal);
        assertEquals("usuarioPrueba", 
            principal.getTitle().contains("usuarioPrueba") ? "usuarioPrueba" : ""); 
    }

    @Test
    void testConstructorUsuarioInvalido() {
        Exception ex = assertThrows(IllegalArgumentException.class, () -> {
            new Principal("", controladorMock);
        });
        assertTrue(ex.getMessage().contains("usuario"));
    }

    @Test
    void testConstructorControladorNulo() {
        Exception ex = assertThrows(IllegalArgumentException.class, () -> {
            new Principal("usuarioPrueba", null);
        });
        assertTrue(ex.getMessage().contains("controlador"));
    }

    @Test
    void testAbrirVentanillaLlamaControlador() {
        Principal principal = new Principal("usuarioPrueba", controladorMock);
        principal.setVisible(false); // Evita abrir UI real
        principal.abrirVentanilla();
        verify(controladorMock, times(1)).abrirVentanilla("usuarioPrueba");
    }

    @Test
    void testAbrirCajeroLlamaControlador() {
        Principal principal = new Principal("usuarioPrueba", controladorMock);
        principal.setVisible(false); 
        principal.abrirCajero();
        verify(controladorMock, times(1)).abrirCajero("usuarioPrueba");
    }

    @Test
    void testMostrarErrorNoLanzaExcepcion() {
        Principal principal = new Principal("usuarioPrueba", controladorMock);
        assertDoesNotThrow(() -> principal.mostrarError("Error de prueba"));
    }
}
