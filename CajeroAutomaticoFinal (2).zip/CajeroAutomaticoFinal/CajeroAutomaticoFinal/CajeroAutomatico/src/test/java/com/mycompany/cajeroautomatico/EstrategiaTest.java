package com.mycompany.cajeroautomatico;

import controlador.estrategias.EstrategiaDeposito;
import controlador.estrategias.EstrategiaRetiro;
import Modelo.ResultadoOperacion;
import Modelo.ServicioUsuario;
import persistencia.ServicioTrans;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class EstrategiaTest {

    private ServicioUsuario servicioUsuarioMock;
    private ServicioTrans servicioTransMock;
    private EstrategiaDeposito estrategiaDeposito;
    private EstrategiaRetiro estrategiaRetiro;

    @BeforeEach
    void setUp() {
        servicioUsuarioMock = mock(ServicioUsuario.class);
        servicioTransMock = mock(ServicioTrans.class);
        estrategiaDeposito = new EstrategiaDeposito(servicioUsuarioMock, servicioTransMock);
        estrategiaRetiro = new EstrategiaRetiro(servicioUsuarioMock, servicioTransMock);
    }

   
}
