package com.mycompany.cajeroautomatico;

import Modelo.ResultadoOperacion;
import Modelo.Usuario;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ModeloTest {

    @Test
    void testUsuarioConstructorYGetters() {
        // Arrange
        String usuario = "testUser ";
        String contrasena = "testPass";
        double saldo = 1000.0;
        String nombreCompleto = "Juan Perez";
        String fechaNacimiento = "1990-01-01";
        String telefono = "123456789";
        String pais = "Ecuador";
        String apellidos = "Perez";
        String correo = "juan@example.com";

        // Act
        Usuario user = new Usuario(usuario, contrasena, saldo, nombreCompleto, fechaNacimiento, telefono, pais, apellidos, correo);

        // Assert
        assertEquals(usuario, user.getUsuario());
        assertEquals(contrasena, user.getContrasena());
        assertEquals(saldo, user.getSaldo());
        assertEquals(nombreCompleto, user.getNombreCompleto());
        assertEquals(fechaNacimiento, user.getFechaNacimiento());
        assertEquals(telefono, user.getTelefono());
        assertEquals(pais, user.getPais());
        assertEquals(apellidos, user.getApellidos());
        assertEquals(correo, user.getCorreo());
    }

    @Test
    void testResultadoOperacionConstructorYGetters() {
        // Arrange
        boolean exito = true;
        String mensaje = "Operación exitosa";

        // Act
        ResultadoOperacion resultado = new ResultadoOperacion(exito, mensaje);

        // Assert
        assertTrue(resultado.isExito());
        assertEquals(mensaje, resultado.getMensaje());
    }

    @Test
    void testResultadoOperacionConstructorYGetters_Fallo() {
        // Arrange
        boolean exito = false;
        String mensaje = "Error en la operación";

        // Act
        ResultadoOperacion resultado = new ResultadoOperacion(exito, mensaje);

        // Assert
        assertFalse(resultado.isExito());
        assertEquals(mensaje, resultado.getMensaje());
    }
}
