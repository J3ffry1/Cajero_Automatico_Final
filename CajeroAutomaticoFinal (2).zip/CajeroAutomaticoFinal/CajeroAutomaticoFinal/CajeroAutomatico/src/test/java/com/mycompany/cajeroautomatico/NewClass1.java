package com.mycompany.cajeroautomatico;

import Modelo.ServicioUsuario;
import command.DepositoCommand;
import persistencia.ServicioTrans;
import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;

public class NewClass1  {
    @Test
    void testExecute() {
        ServicioUsuario mockServicio = mock(ServicioUsuario.class);
        ServicioTrans mockTrans = mock(ServicioTrans.class);
        DepositoCommand command = new DepositoCommand(mockServicio, mockTrans, "user1", 100.0);
        
        command.execute();
        
        verify(mockServicio).actualizarSaldo("user1", 100.0);
        verify(mockTrans).registrarTransaccion("user1", "DEPOSITO", 100.0);
    }

    @Test
    void testUndo() {
        ServicioUsuario mockServicio = mock(ServicioUsuario.class);
        ServicioTrans mockTrans = mock(ServicioTrans.class);
        DepositoCommand command = new DepositoCommand(mockServicio, mockTrans, "user1", 100.0);
        
        command.undo();
        
        verify(mockServicio).actualizarSaldo("user1", -100.0);
        verify(mockTrans).registrarTransaccion("user1", "DESHACER DEPOSITO", -100.0);
    }
}