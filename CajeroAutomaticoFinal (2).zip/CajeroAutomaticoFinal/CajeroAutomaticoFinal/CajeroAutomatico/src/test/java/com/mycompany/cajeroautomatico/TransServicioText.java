/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cajeroautomatico;


import org.junit.jupiter.api.*;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

import static org.junit.jupiter.api.Assertions.*;
import persistencia.TransServicio;

class TransServicioTest {

    private TransServicio servicio;
    private static final String CSV_FILE = "transacciones.csv";

    @BeforeEach
    void setUp() throws Exception {
        servicio = new TransServicio();

        // Limpia el archivo antes de cada prueba
        Files.deleteIfExists(Paths.get(CSV_FILE));
    }

    @Test
    @DisplayName("Debe registrar una transacción en el archivo CSV")
    void testRegistrarTransaccion() {
        servicio.registrarTransaccion("usuarioTest", "DEPÓSITO", 100.0);

        File file = new File(CSV_FILE);
        assertTrue(file.exists(), "El archivo CSV debe crearse");

        String contenido = leerArchivo();
        assertTrue(contenido.contains("usuarioTest"), "El historial debe contener el usuario registrado");
    }

    @Test
    @DisplayName("Debe obtener historial vacío si no hay registros")
    void testObtenerHistorialVacio() {
        String historial = servicio.obtenerHistorial("usuarioTest");
        assertTrue(historial.contains("No hay transacciones registradas") 
                || historial.contains("No hay historial disponible"),
                "Debe indicar que no hay historial");
    }

    @Test
    @DisplayName("Debe obtener historial con registros existentes")
    void testObtenerHistorialConRegistros() {
        servicio.registrarTransaccion("usuarioTest", "RETIRO", 50.0);
        String historial = servicio.obtenerHistorial("usuarioTest");
        assertTrue(historial.contains("usuarioTest"), "El historial debe mostrar el usuario registrado");
        assertTrue(historial.contains("RETIRO"), "El historial debe contener el tipo de transacción");
    }

    @Test
    @DisplayName("Debe validar correctamente el límite de transacción")
    void testValidarLimiteTransaccion() {
        assertTrue(servicio.validarLimiteTransaccion(1000.0), "Debe aceptar transacciones menores al límite");
        assertFalse(servicio.validarLimiteTransaccion(6000.0), "Debe rechazar transacciones mayores al límite");
    }

    // Método auxiliar para leer archivo CSV
    private String leerArchivo() {
        try {
            return new String(Files.readAllBytes(Paths.get(CSV_FILE)));
        } catch (IOException e) {
            fail("Error al leer archivo: " + e.getMessage());
            return "";
        }
    }
}
