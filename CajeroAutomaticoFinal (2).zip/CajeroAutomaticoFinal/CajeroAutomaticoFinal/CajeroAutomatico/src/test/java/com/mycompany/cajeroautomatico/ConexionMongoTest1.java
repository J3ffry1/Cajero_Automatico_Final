package com.mycompany.cajeroautomatico;

import persistencia.ConexionMongo;
import Modelo.Usuario;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ConexionMongoTest1 {

    private ConexionMongo conexionMongo;

    @BeforeEach
    void setUp() {
        conexionMongo = new ConexionMongo();
    }

    @Test
    void testGuardarUsuario() {
        // Arrange
        Usuario usuario = new Usuario("newUser ", "newPass", 100.0, "John Doe", "1990-01-01", "123456789", "USA", "Doe", "john@example.com");

        // Act
        conexionMongo.guardarUsuario(usuario);

        // Assert
        // Verificar que el usuario se guardó correctamente en la base de datos
        // Esto dependerá de cómo hayas implementado la lógica de guardado
    }

    @Test
    void testAutenticarUsuario_CredencialesCorrectas() {
        // Arrange
        String usuario = "testUser ";
        String contrasena = "testPass";

        // Act
        boolean resultado = conexionMongo.autenticarUsuario(usuario, contrasena);

        // Assert
        assertTrue(resultado);
    }

    @Test
    void testObtenerSaldo_UsuarioExistente() {
        // Arrange
        String usuario = "testUser ";

        // Act
        double saldo = conexionMongo.obtenerSaldo(usuario);

        // Assert
        assertEquals(1000.0, saldo); // Cambia esto según el saldo que esperas
    }

    @Test
    void testActualizarSaldo_UsuarioExistente() {
        // Arrange
        String usuario = "testUser ";
        double nuevoSaldo = 1500.0;

        // Act
        conexionMongo.actualizarSaldo(usuario, nuevoSaldo);

        // Assert
        double saldoActual = conexionMongo.obtenerSaldo(usuario);
        assertEquals(nuevoSaldo, saldoActual);
    }

    @Test
    void testVerificarCuentaExistente_CuentaExiste() {
        // Arrange
        String usuario = "existingUser ";

        // Act
        boolean existe = conexionMongo.verificarCuentaExistente(usuario);

        // Assert
        assertTrue(existe);
    }

    @Test
    void testVerificarCuentaExistente_CuentaNoExiste() {
        // Arrange
        String usuario = "nonExistingUser ";

        // Act
        boolean existe = conexionMongo.verificarCuentaExistente(usuario);

        // Assert
        assertFalse(existe);
    }

    @Test
    void testObtenerNombreCuenta_CuentaExiste() {
        // Arrange
        String usuario = "testUser ";

        // Act
        String nombre = conexionMongo.obtenerNombreCuenta(usuario);

        // Assert
        assertEquals("John Doe", nombre); // Cambia esto según el nombre que esperas
    }

    @Test
    void testObtenerNombreCuenta_CuentaNoExiste() {
        // Arrange
        String usuario = "nonExistingUser ";

        // Act
        String nombre = conexionMongo.obtenerNombreCuenta(usuario);

        // Assert
        assertEquals("Cuenta no encontrada", nombre);
    }
}
