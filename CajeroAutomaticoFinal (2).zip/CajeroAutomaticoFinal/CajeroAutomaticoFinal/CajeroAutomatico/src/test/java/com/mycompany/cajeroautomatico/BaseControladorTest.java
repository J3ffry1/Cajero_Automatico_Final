/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cajeroautomatico;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.*;
import Modelo.ServicioUsuario;
import controlador.BaseControlador;

public class BaseControladorTest {

    // Clase concreta mínima para testear BaseControlador
    static class ControladorDummy extends BaseControlador {
        public ControladorDummy(ServicioUsuario servicioUsuario) {
            super(servicioUsuario);
        }
        
        public ServicioUsuario getServicio() {
            return servicioUsuario;
        }
    }

    ServicioUsuario servicioMock;
    ControladorDummy controlador;

    @BeforeEach
    void setUp() {
        servicioMock = new ServicioUsuario() {
            @Override
            public boolean autenticarUsuario(String usuario, String contrasena) {
                return false;
            }
            @Override
            public void guardarUsuario(Modelo.Usuario usuario) {}
            @Override
            public double obtenerSaldo(String usuario) { return 0; }
            @Override
            public void actualizarSaldo(String usuario, double monto) {}
            @Override
            public boolean verificarCuentaExistente(String numeroCuenta) { return false; }
            @Override
            public String obtenerNombreCuenta(String numeroCuenta) { return null; }
        };
        controlador = new ControladorDummy(servicioMock);
    }

    @Test
    void testServicioUsuarioNoEsNull() {
        assertNotNull(controlador.getServicio(), "El servicioUsuario debe estar inicializado");
    }

    @Test
    void testServicioUsuarioEsElMismo() {
        assertEquals(servicioMock, controlador.getServicio(), "El servicioUsuario debe ser el mismo que se pasó al constructor");
    }
}

