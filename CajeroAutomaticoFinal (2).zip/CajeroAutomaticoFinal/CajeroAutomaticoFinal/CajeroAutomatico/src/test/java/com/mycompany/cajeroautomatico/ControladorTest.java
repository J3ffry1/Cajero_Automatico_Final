/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cajeroautomatico;

import Modelo.ServicioUsuario;
import command.CommandHistory;
import controlador.DepositoControlador;
import controlador.InicioControlador;
import controlador.MenuControlador;
import controlador.PersonalVenContro;
import controlador.RetiroControlador;
import controlador.TransIContro;
import persistencia.ServicioTrans;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

class ControladorTest {
    private ServicioUsuario usuarioMock;
    private ServicioTrans transMock;
    
    @BeforeEach
    void setUp() {
        usuarioMock = mock(ServicioUsuario.class);
        transMock = mock(ServicioTrans.class);
    }

    // Tests para DepositoControlador
    @Test
    void testDepositoControladorRealizarDepositoExitoso() {
        when(usuarioMock.obtenerSaldo("user1")).thenReturn(500.0);
        
        DepositoControlador controlador = new DepositoControlador(usuarioMock, transMock);
        var resultado = controlador.realizarDeposito("user1", 200.0);
        
        assertTrue(resultado.isExito());
        assertTrue(resultado.getMensaje().contains("Nuevo saldo"));
        assertTrue(controlador.puedeDeshacer());
    }

    @Test
    void testDepositoControladorValidaciones() {
        DepositoControlador controlador = new DepositoControlador(usuarioMock, transMock);
        
        // Test monto negativo
        var resultadoNegativo = controlador.realizarDeposito("user1", -100.0);
        assertFalse(resultadoNegativo.isExito());
        assertEquals("El monto debe ser mayor a cero", resultadoNegativo.getMensaje());
        
        // Test límite excedido
        var resultadoLimite = controlador.realizarDeposito("user1", 2000.0);
        assertFalse(resultadoLimite.isExito());
        assertTrue(resultadoLimite.getMensaje().contains("Excede el límite"));
    }

    // Tests para RetiroControlador
    @Test
    void testRetiroControladorRealizarRetiroExitoso() {
        when(usuarioMock.obtenerSaldo("user1")).thenReturn(500.0);
        
        RetiroControlador controlador = new RetiroControlador(usuarioMock, transMock);
        var resultado = controlador.realizarRetiro("user1", 200.0);
        
        assertTrue(resultado.isExito());
        assertTrue(resultado.getMensaje().contains("Nuevo saldo"));
        assertTrue(controlador.puedeDeshacer());
    }

   
   
    
    // Tests para MenuControlador
    @Test
    void testMenuControladorFuncionalidadesBasicas() {
        when(usuarioMock.obtenerSaldo("user1")).thenReturn(500.0);
        when(transMock.obtenerHistorial("user1")).thenReturn("Historial de transacciones");
        
        MenuControlador controlador = new MenuControlador(usuarioMock, transMock);
        
        assertEquals(500.0, controlador.obtenerSaldo("user1"));
        assertEquals("Historial de transacciones", controlador.obtenerHistorial("user1"));
    }

    // Tests para InicioControlador
    @Test
    void testInicioControladorAutenticacion() {
        when(usuarioMock.autenticarUsuario("user1", "pass123")).thenReturn(true);
        when(usuarioMock.autenticarUsuario("user1", "wrong")).thenReturn(false);
        
        InicioControlador controlador = new InicioControlador(usuarioMock, transMock);
        
        assertTrue(controlador.autenticarUsuario("user1", "pass123"));
        assertFalse(controlador.autenticarUsuario("user1", "wrong"));
    }

    // Tests para PersonalVenContro
 
}