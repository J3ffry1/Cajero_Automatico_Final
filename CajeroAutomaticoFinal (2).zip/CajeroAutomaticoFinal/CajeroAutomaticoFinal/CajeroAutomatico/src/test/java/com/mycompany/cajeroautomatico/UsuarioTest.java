/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.cajeroautomatico;
import Modelo.Usuario;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class UsuarioTest {

    @Test
    public void testGetters() {
        Usuario user = new Usuario("jeffry123", "1234", 100.0, "Jeffry Verq", "2000-01-01", "0999999999", "Ecuador", "Verq", "jeffry@email.com");

        assertEquals("jeffry123", user.getUsuario());
        assertEquals("1234", user.getContrasena());
        assertEquals(100.0, user.getSaldo());
        assertEquals("Jeffry Verq", user.getNombreCompleto());
        assertEquals("2000-01-01", user.getFechaNacimiento());
        assertEquals("0999999999", user.getTelefono());
        assertEquals("jeffry@email.com", user.getCorreo());
        assertEquals("Ecuador", user.getPais());
        assertEquals("Verq", user.getApellidos());
    }

    @Test
    public void testSetters() {
        Usuario user = new Usuario("user", "pass", 0, "", "", "", "", "", "");

        user.setUsuario("nuevoUser");
        user.setContrasena("nuevaPass");
        user.setSaldo(500.0);
        user.setNombreCompleto("Nuevo Nombre");
        user.setFechaNacimiento("1990-12-12");
        user.setTelefono("0988888888");
        user.setCorreo("nuevo@email.com");
        user.setPais("Colombia");
        user.setApellidos("ApellidoNuevo");

        assertEquals("nuevoUser", user.getUsuario());
        assertEquals("nuevaPass", user.getContrasena());
        assertEquals(500.0, user.getSaldo());
        assertEquals("Nuevo Nombre", user.getNombreCompleto());
        assertEquals("1990-12-12", user.getFechaNacimiento());
        assertEquals("0988888888", user.getTelefono());
        assertEquals("nuevo@email.com", user.getCorreo());
        assertEquals("Colombia", user.getPais());
        assertEquals("ApellidoNuevo", user.getApellidos());
    }

    @Test
    public void testLimiteSaldo() {
        Usuario user = new Usuario("user", "pass", -50.0, "", "", "", "", "", "");
        assertTrue(user.getSaldo() < 0, "El saldo puede ser negativo en este caso.");
    }
}